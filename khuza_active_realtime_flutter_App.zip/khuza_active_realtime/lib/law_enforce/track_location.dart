import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class TrackLocationScreen extends StatelessWidget {
  final Map<String, dynamic> location;

  const TrackLocationScreen({super.key, required this.location});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Track Location'),
      ),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: LatLng(location['latitude'], location['longitude']),
          zoom: 14,
        ),
        markers: {
          Marker(
            markerId: const MarkerId('tracked_location'),
            position: LatLng(location['latitude'], location['longitude']),
          ),
        },
        polylines: {
          Polyline(
            polylineId: const PolylineId('route'),
            points: [
              LatLng(location['latitude'], location['longitude']),
              // Add additional coordinates for the polyline if needed
            ],
            color: Colors.blue,
            width: 5,
          ),
        },
      ),
    );
  }
}
