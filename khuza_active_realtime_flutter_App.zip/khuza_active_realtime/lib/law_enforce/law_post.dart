import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class LawPostPage extends StatefulWidget {
  const LawPostPage({super.key});

  @override
  _LawPostPageState createState() => _LawPostPageState();
}

class _LawPostPageState extends State<LawPostPage> {
  final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref();
  List<Map<dynamic, dynamic>> post = [];
  List<String> postKeys = []; // List to hold keys of the posts

  @override
  void initState() {
    super.initState();
    fetchCrimeReport();
  }

  Future<void> fetchCrimeReport() async {
    try {
      DatabaseEvent firebaseData =
          await _databaseReference.child('Post').once();
      List<Map<String, dynamic>> firebasePost = [];

      if (firebaseData.snapshot.value != null) {
        final Map<dynamic, dynamic> postsMap =
            firebaseData.snapshot.value as Map<dynamic, dynamic>;

        firebasePost = postsMap.entries.map((entry) {
          final value = entry.value as Map;
          final resident =
              value['Resident'] ?? {}; // Fetch nested ResidentModel if exists

          // Store the unique key for deletion later
          postKeys.add(entry.key.toString());

          return {
            'id': entry.key, // Store the unique key for updates
            'Title': value['Title'] ?? 'Unknown Crime Type',
            'Description': value['Description'] ?? 'No details provided',
            'Location': value['Location'] ?? 'Unknown location',
            'Date': value['Date'] ?? 'Unknown date',
            'Time': value['Time'] ?? 'Unknown time',
            'Status': value['Status'] ?? 'Submitted', // Include Status
            'UploadPhoto': value['UploadPhoto'], // Handle photo URL if exists
            'ResidentId': resident['ResidentId'] ?? 'Unknown',
            'FirstName': resident['FirstName'] ?? 'Unknown',
            'LastName': resident['LastName'] ?? 'Unknown',
            'Email': resident['Email'] ?? 'Unknown',
            'StreetName': resident['StreetName'] ?? '',
            'Suburb': resident['Suburb'] ?? '',
            'City': resident['City'] ?? '',
            'Province': resident['Province'] ?? '',
          };
        }).toList();
      }

      setState(() {
        post = firebasePost;
      });
    } catch (e) {
      setState(() {
        post = [];
      });
      print("Error fetching posts: $e");
    }
  }

  Future<void> _updateReportStatus(String postId, String newStatus) async {
    try {
      await _databaseReference
          .child('Post/$postId')
          .update({'Status': newStatus});
      // Optionally, you can show a success message or refresh the list
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Status updated to $newStatus')),
      );
    } catch (e) {
      print("Error updating status: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(156, 40, 189, 235),
        title: const Text('Crime Reports'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: post.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: post.length,
              itemBuilder: (context, index) {
                final posts = post[index]; // Get the corresponding key
                final title = posts['Title'] ?? 'Unknown';
                final location = posts['Location'] ?? 'Unknown Location';
                final description = posts['Description'] ?? 'No details';
                final date = posts['Date'] ?? 'Date Unknown';
                final residentName =
                    "${posts['FirstName']} ${posts['LastName']}";
                final uploadPhoto = posts['UploadPhoto'] ?? '';
                final time = posts['Time'] ?? 'Unknown Time';
                final postId = posts['id']; // Get post ID for updating

                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title.toUpperCase(),
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            "Location: $location",
                            style: const TextStyle(
                              fontSize: 15,
                              color: Colors.black54,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            "Details: $description",
                            style: const TextStyle(
                              fontSize: 14,
                              color: Colors.black87,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            "Date: $date",
                            style: const TextStyle(
                              fontSize: 14,
                              color: Colors.black54,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            "Time: $time",
                            style: const TextStyle(
                              fontSize: 14,
                              color: Colors.black54,
                            ),
                          ),
                          const SizedBox(height: 12),
                          uploadPhoto.isNotEmpty
                              ? ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Image.network(
                                    uploadPhoto,
                                    fit: BoxFit.cover,
                                    height: 200,
                                    width: double.infinity,
                                    errorBuilder:
                                        (context, error, stackTrace) =>
                                            const Text('Error loading image'),
                                  ),
                                )
                              : const Text(
                                  'No image available',
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.grey),
                                ),
                          const SizedBox(height: 12),
                          const Divider(),
                          Text(
                            "Reported by: $residentName",
                            style: const TextStyle(
                              fontSize: 14,
                              fontStyle: FontStyle.italic,
                              color: Colors.black87,
                            ),
                          ),
                          const SizedBox(height: 8),
                          // Dropdown for status
                          DropdownButton<String>(
                            value: posts['Status'], // Current status
                            items: <String>[
                              'Submitted',
                              'Under Investigation',
                              'Pending',
                              'Resolved',
                            ].map((String status) {
                              return DropdownMenuItem<String>(
                                value: status,
                                child: Text(status),
                              );
                            }).toList(),
                            onChanged: (String? newStatus) {
                              if (newStatus != null) {
                                _updateReportStatus(
                                    postId, newStatus); // Update the status
                              }
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
