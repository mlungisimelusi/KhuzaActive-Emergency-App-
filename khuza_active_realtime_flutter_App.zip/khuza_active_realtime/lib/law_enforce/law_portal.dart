import 'package:flutter/material.dart';
import 'package:khuza_active_realtime/Widgets/box.dart';
import 'package:khuza_active_realtime/Widgets/button.dart';
import 'package:khuza_active_realtime/law_enforce/law_alerts.dart';
import 'package:khuza_active_realtime/law_enforce/law_post.dart';
import 'package:khuza_active_realtime/law_enforce/track_location.dart';

class LawPortal extends StatelessWidget {
  const LawPortal({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Security Company'),
        backgroundColor: Colors.lightBlue,
      ),
      body: Center(
          child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text(
            'Stay Safe Stay Alert',
            style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                fontStyle: FontStyle.italic,
                color: Colors.blue),
          ),
          const SizedBox(
            height: 40,
          ),
          Column(children: [
            myBox(
              name: 'Reports',
              color: const Color.fromARGB(156, 47, 141, 255),
              icon: const Icon(
                Icons.report,
                size: 70,
              ),
            
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const LawPostPage()));
              },
            ),
            const SizedBox(
              height: 25,
            ),
            myBox(
              name: 'Alerts',
              color: const Color.fromARGB(156, 72, 238, 169),
              icon: const Icon(
                Icons.notifications_active,
                size: 70,
              ),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const AlertsPage()));
              },
            ),
            const SizedBox(
              height: 25,
            ),
            ElevatedButton(
              style: registerButton,
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const TrackLocationScreen(
                              location: {},
                            )));
              },
              child: const Text(
                'Back',
                style: TextStyle(color: Colors.white, fontSize: 20),
              ),
            ),
          ])
        ],
      )),
    );
  }
}
