// import 'package:flutter/material.dart';
// import 'package:firebase_database/firebase_database.dart';
// import 'package:geocoding/geocoding.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';
// import 'package:khuza_active_realtime/law_enforce/track_location.dart';

// class LawAlertsPage extends StatefulWidget {
//   const LawAlertsPage({super.key});

//   @override
//   _LawAlertsPageState createState() => _LawAlertsPageState();
// }

// class _LawAlertsPageState extends State<LawAlertsPage> {
//   final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref();
//   List<Map<String, dynamic>> alertsList = [];

//   @override
//   void initState() {
//     super.initState();
//     fetchFirebaseData();
//   }

//   void _trackLocation(Map<String, dynamic> location) {
//     Navigator.push(
//       context,
//       MaterialPageRoute(
//         builder: (context) => TrackLocationScreen(location: location),
//       ),
//     );
//   }

// Future<void> fetchFirebaseData() async {
//   try {
//     DatabaseEvent firebaseData =
//         await _databaseReference.child('Alert').once();
//     List<Map<String, dynamic>> firebaseAlerts = [];

//     if (firebaseData.snapshot.value != null) {
//       final Map<dynamic, dynamic> alertsMap =
//           firebaseData.snapshot.value as Map<dynamic, dynamic>;

//       firebaseAlerts = alertsMap.entries.map((entry) {
//         final value = entry.value as Map;
//         final resident = value['Resident'] ?? {};

//         return {
//           'id': entry.key, // Add alert key for identification and deletion
//           'ResidentId': resident['ResidentId'] ?? 'Unknown',
//           'FirstName': resident['FirstName'] ?? 'Unknown',
//           'LastName': resident['LastName'] ?? 'Unknown',
//           'Email': resident['Email'] ?? 'Unknown',
//           'StreetName': resident['StreetName'] ?? 'Unknown',
//           'Suburb': resident['Suburb'] ?? 'Unknown',
//           'City': resident['City'] ?? 'Unknown',
//           'Province': resident['Province'] ?? 'Unknown',

//         };
//       }).toList();
//     }

//     setState(() {
//       alertsList = firebaseAlerts;
//     });
//   } catch (e) {
//     setState(() {
//       alertsList = [];
//     });
//     print("Error fetching alerts: $e");
//   }
// }

///
library;

// Function to fetch data from Firebase
//   Future<void> fetchFirebaseData() async {
//     try {
//       _databaseReference.child("Alert").onValue.listen((event) {
//         final data = event.snapshot.value;
//         if (data != null && data is Map) {
//           List<Map<String, dynamic>> firebaseAlerts = [];
//           data.forEach((key, value) {
//             if (value is Map) {
//               // Extract Resident and Alert data
//               final resident = value['Resident'] ?? {};
//               final routeCoordinates = (value['routeCoordinates'] as List?)
//                   ?.map((coord) => LatLng(
//                         coord['latitude'],
//                         coord['longitude'],
//                       ))
//                   .toList();

//               firebaseAlerts.add({
//                 'ResidentId': resident['ResidentId'] ?? 'Unknown',
//                 'FirstName': resident['FirstName'] ?? 'Unknown',
//                 'LastName': resident['LastName'] ?? 'Unknown',
//                 'Email': resident['Email'] ?? 'Unknown',
//                 'StreetName': resident['StreetName'] ?? 'Unknown',
//                 'Suburb': resident['Suburb'] ?? 'Unknown',
//                 'City': resident['City'] ?? 'Unknown',
//                 'Province': resident['Province'] ?? 'Unknown',
//                 'latitude': value['latitude'],
//                 'longitude': value['longitude'],
//                 'Alert_Address': value['Alert_Address'] ?? 'Unknown',
//                 'routeCoordinates': routeCoordinates ?? [],
//               });
//             }
//           });

//           // Update the state with fetched data
//           setState(() {
//             alertsList = firebaseAlerts;
//           });
//         }
//       });
//     } catch (e) {
//       print("Error fetching alerts: $e");
//       setState(() {
//         alertsList = [];
//       });
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: const Color(0xffD0C3FF),
//         title: const Text('Community Alerts'),
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back),
//           onPressed: () => Navigator.pop(context),
//         ),
//       ),
//       body: alertsList.isEmpty
//           ? const Center(child: CircularProgressIndicator())
//           : ListView.builder(
//               itemCount: alertsList.length,
//               itemBuilder: (context, index) {
//                 final alert = alertsList[index];
//                 final residentName =
//                     "${alert['FirstName']} ${alert['LastName']}".toUpperCase();
//                 final email = alert['Email'] ?? 'Unknown email';
//                 final address = alert['Alert_Address'] ?? 'No address provided';

//                 return Padding(
//                   padding: const EdgeInsets.all(16.0),
//                   child: Card(
//                     shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(15)),
//                     child: ListTile(
//                       leading: const Icon(Icons.location_on,
//                           color: Colors.blue), // Tracking icon
//                       title: Text(
//                         "${alert['FirstName']} ${alert['LastName']}"
//                             .toUpperCase(),
//                         style: const TextStyle(fontWeight: FontWeight.bold),
//                       ),
//                       subtitle: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text(alert['Email']),
//                           Text("Address: ${alert['Alert_Address']}"),
//                         ],
//                       ),
//                       trailing: IconButton(
//                         icon: const Icon(Icons.track_changes),
//                         onPressed: () {},
//                       ),
//                     ),
//                   ),
//                 );
//               },
//             ),
//     );
//   }
// }
//Test1
// import 'package:flutter/material.dart';
// import 'package:firebase_database/firebase_database.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';
// import 'tracking_page.dart';

// class AlertsPage extends StatefulWidget {
//   const AlertsPage({super.key});

//   @override
//   _AlertsPageState createState() => _AlertsPageState();
// }

// class _AlertsPageState extends State<AlertsPage> {
//   final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref();
//   List<Map<String, dynamic>> alertsList = [];

//   @override
//   void initState() {
//     super.initState();
//     fetchFirebaseData();
//   }

//   // Function to fetch data from Firebase
//   Future<void> fetchFirebaseData() async {
//     try {
//       _databaseReference.child("Alert").onValue.listen((event) {
//         final data = event.snapshot.value;
//         if (data != null && data is Map) {
//           List<Map<String, dynamic>> firebaseAlerts = [];
//           data.forEach((key, value) {
//             if (value is Map) {
//               final resident = value['Resident'] ?? {};
//               final routeCoordinates = (value['routeCoordinates'] as List?)
//                   ?.map((coord) => LatLng(
//                         coord['latitude'],
//                         coord['longitude'],
//                       ))
//                   .toList();

//               firebaseAlerts.add({
//                 'ResidentId': resident['ResidentId'] ?? 'Unknown',
//                 'FirstName': resident['FirstName'] ?? 'Unknown',
//                 'LastName': resident['LastName'] ?? 'Unknown',
//                 'Email': resident['Email'] ?? 'Unknown',
//                 'StreetName': resident['StreetName'] ?? 'Unknown',
//                 'Suburb': resident['Suburb'] ?? 'Unknown',
//                 'City': resident['City'] ?? 'Unknown',
//                 'Province': resident['Province'] ?? 'Unknown',
//                 'latitude': value['latitude'],
//                 'longitude': value['longitude'],
//                 'Alert_Address': value['Alert_Address'] ?? 'Unknown',
//                 'routeCoordinates': routeCoordinates ?? [],
//               });
//             }
//           });

//           setState(() {
//             alertsList = firebaseAlerts;
//           });
//         }
//       });
//     } catch (e) {
//       print("Error fetching alerts: $e");
//       setState(() {
//         alertsList = [];
//       });
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: const Color(0xffD0C3FF),
//         title: const Text(
//           'Community Alerts',
//           style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
//         ),
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back, color: Colors.black),
//           onPressed: () => Navigator.pop(context),
//         ),
//       ),
//       body: alertsList.isEmpty
//           ? const Center(
//               child: Text(
//                 'No alerts available',
//                 style: TextStyle(fontSize: 18, color: Colors.grey),
//               ),
//             )
//           : ListView.builder(
//               padding: const EdgeInsets.all(10.0),
//               itemCount: alertsList.length,
//               itemBuilder: (context, index) {
//                 final alert = alertsList[index];
//                 final residentName =
//                     "${alert['FirstName']} ${alert['LastName']}".toUpperCase();
//                 final email = alert['Email'] ?? 'Unknown email';
//                 final address = alert['Alert_Address'] ?? 'No address provided';
//                 final latitude = alert['latitude'];
//                 final longitude = alert['longitude'];

//                 return Padding(
//                   padding: const EdgeInsets.symmetric(vertical: 8.0),
//                   child: Card(
//                     elevation: 5,
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(15),
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.all(16.0),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text(
//                             residentName,
//                             style: const TextStyle(
//                               fontSize: 18,
//                               fontWeight: FontWeight.bold,
//                               color: Colors.teal,
//                             ),
//                           ),
//                           const SizedBox(height: 8),
//                           Row(
//                             children: [
//                               const Icon(Icons.email, color: Colors.grey),
//                               const SizedBox(width: 8),
//                               Text(
//                                 email,
//                                 style: const TextStyle(
//                                   fontSize: 14,
//                                   color: Colors.black87,
//                                 ),
//                               ),
//                             ],
//                           ),
//                           const Divider(height: 20, thickness: 1),
//                           Row(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               const Icon(Icons.location_on, color: Colors.grey),
//                               const SizedBox(width: 8),
//                               Expanded(
//                                 child: Text(
//                                   "Address: $address",
//                                   style: const TextStyle(
//                                     fontSize: 14,
//                                     color: Colors.black87,
//                                   ),
//                                 ),
//                               ),
//                             ],
//                           ),
//                           const SizedBox(height: 10),
//                           ElevatedButton.icon(
//                             onPressed: () {
//                               if (latitude != null && longitude != null) {
//                                 Navigator.push(
//                                   context,
//                                   MaterialPageRoute(
//                                     builder: (context) => TrackingPage(
//                                       latitude: latitude,
//                                       longitude: longitude,
//                                     ),
//                                   ),
//                                 );
//                               }
//                             },
//                             icon: const Icon(Icons.location_searching),
//                             label: const Text('Track Location'),
//                             style: ElevatedButton.styleFrom(
//                               backgroundColor: Colors.teal,
//                               shape: RoundedRectangleBorder(
//                                 borderRadius: BorderRadius.circular(8),
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                 );
//               },
//             ),
//     );
//   }
// }
//Test 2
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'tracking_page.dart';

class AlertsPage extends StatefulWidget {
  const AlertsPage({super.key});

  @override
  _AlertsPageState createState() => _AlertsPageState();
}

class _AlertsPageState extends State<AlertsPage> {
  final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref();
  List<Map<String, dynamic>> alertsList = [];
  Position? userPosition;

  @override
  void initState() {
    super.initState();
    fetchUserLocation();
    fetchFirebaseData();
  }

  Future<void> fetchUserLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Check if location services are enabled
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Request location services to be enabled
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Location services are disabled. Please enable them."),
        ),
      );
      return;
    }

    // Check for location permissions
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Location permissions are denied."),
          ),
        );
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // Permissions are permanently denied
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
              "Location permissions are permanently denied. Please enable them in settings."),
        ),
      );
      return;
    }

    // Fetch the current position
    Position position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );

    setState(() {
      userPosition = position;
    });
  }

  Future<void> fetchFirebaseData() async {
    try {
      _databaseReference.child("Alert").onValue.listen((event) {
        final data = event.snapshot.value;
        if (data != null && data is Map) {
          List<Map<String, dynamic>> firebaseAlerts = [];
          data.forEach((key, value) {
            if (value is Map) {
              final resident = value['Resident'] ?? {};
              final routeCoordinates = (value['routeCoordinates'] as List?)
                  ?.map((coord) => LatLng(
                        coord['latitude'],
                        coord['longitude'],
                      ))
                  .toList();

              firebaseAlerts.add({
                'ResidentId': resident['ResidentId'] ?? 'Unknown',
                'FirstName': resident['FirstName'] ?? 'Unknown',
                'LastName': resident['LastName'] ?? 'Unknown',
                'Email': resident['Email'] ?? 'Unknown',
                'StreetName': resident['StreetName'] ?? 'Unknown',
                'Suburb': resident['Suburb'] ?? 'Unknown',
                'City': resident['City'] ?? 'Unknown',
                'Province': resident['Province'] ?? 'Unknown',
                'latitude': value['latitude'],
                'longitude': value['longitude'],
                'companyLatitude': value['latitude'],
                'companyLongitude': value['longitude'],
                'Alert_Address': value['Alert_Address'] ?? 'Unknown',
                'routeCoordinates': routeCoordinates ?? [],
              });
            }
          });

          setState(() {
            alertsList = firebaseAlerts;
          });
        }
      });
    } catch (e) {
      print("Error fetching alerts: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Error fetching alerts: $e"),
        ),
      );
      setState(() {
        alertsList = [];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xffD0C3FF),
        title: const Text(
          'Community Alerts',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: alertsList.isEmpty
          ? const Center(
              child: Text(
                'No alerts available',
                style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(10.0),
              itemCount: alertsList.length,
              itemBuilder: (context, index) {
                final alert = alertsList[index];
                final residentName =
                    "${alert['FirstName']} ${alert['LastName']}".toUpperCase();
                final email = alert['Email'] ?? 'Unknown email';
                final addressLocation =
                    "${alert['StreetName']},${alert['Suburb']}, ${alert['City']}, ${alert['Province']}";
                final latitude = alert['latitude'];
                final longitude = alert['longitude'];
                final routeCoordinates = alert['routeCoordinates'];

                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            residentName,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.teal,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              const Icon(Icons.email, color: Colors.grey),
                              const SizedBox(width: 8),
                              Text(
                                email,
                                style: const TextStyle(
                                  fontSize: 14,
                                  color: Colors.black87,
                                ),
                              ),
                            ],
                          ),
                          const Divider(height: 20, thickness: 1),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Icon(Icons.location_on, color: Colors.grey),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  "Address: $addressLocation",
                                  style: const TextStyle(
                                    fontSize: 14,
                                    color: Colors.black87,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          ElevatedButton.icon(
                            onPressed: () {
                              if (latitude != null &&
                                      longitude != null &&
                                      routeCoordinates != null
                                  //routeCoordinates.isNotEmpty
                                  ) {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => TrackingPage(
                                        latitude: latitude,
                                        longitude: longitude,
                                        routeCoordinates: routeCoordinates,
                                        location: {
                                          'ResidentName':
                                              "${alert['FirstName']} ${alert['LastName']}",
                                          'Email': alert['Email'],
                                          'Address':
                                              "${alert['Alert_Address']}",
                                          'Latitude': latitude,
                                          'Longitude': longitude,
                                        }),
                                  ),
                                );
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text(
                                      "Location data is incomplete for tracking.",
                                    ),
                                  ),
                                );
                              }
                            },
                            icon: const Icon(Icons.location_searching),
                            label: const Text(
                              'Track Location',
                              style: TextStyle(color: Colors.white),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.teal,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
