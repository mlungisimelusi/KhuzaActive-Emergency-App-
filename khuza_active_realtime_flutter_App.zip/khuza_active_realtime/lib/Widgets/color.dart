import 'package:flutter/material.dart';

Color blackPrimary = const Color(0xff212131);
Color black = const Color(0xff09050D);
Color grey = const Color(0xffCBCCD5);
Color orange = const Color(0xffFF815E);
Color white = const Color(0xffffffff);
Color purple = const Color(0xff613FE5);
Color softPurple = const Color(0xffD0C3FF);
Color blue = const Color(0xFF3ac3cb);
Color midBlue = const Color(0x003b79fb);
Color green =  const Color.fromARGB(156, 72, 238, 169);
