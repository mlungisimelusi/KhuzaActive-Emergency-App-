import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:khuza_active_realtime/Model/law_enforceModel.dart';

class LawEnforceProvider extends ChangeNotifier {
  final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref();
  final FirebaseAuth _auth3 = FirebaseAuth.instance;
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  Future<String> addLawEnforce(
    TextEditingController lawEnforceEmailController,
    TextEditingController passwordController,
  ) async {
    try {
      _setLoading(true);
      // Get current user ID
      User? currentUser = _auth3.currentUser;
      if (currentUser == null) {
        _setLoading(false);
        return "NOT OK"; // Return NOT OK if the user is not authenticated
      }

      String lawEnforceId =
          currentUser.uid; // Use the current user's ID as residentId

      LawEnforce lawEnforce = LawEnforce(
        lawEnforceId: lawEnforceId,
        lawEnforceEmail: lawEnforceEmailController.text,
        password: passwordController.text,
      );
      await _databaseReference
          .child('AccessRight/lawEnforce/$lawEnforceId')
          .set(lawEnforce.toMap());

      notifyListeners();
      _setLoading(false);
      return "OK";
    } catch (e) {
      _setLoading(false);
      print('Error adding resident: $e');
      return "NOT OK";
    }
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
}
