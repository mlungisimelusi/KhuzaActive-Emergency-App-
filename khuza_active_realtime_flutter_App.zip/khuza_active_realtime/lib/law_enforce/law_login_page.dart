import 'package:flutter/material.dart';
import 'package:khuza_active_realtime/Screen/register.dart';
import 'package:khuza_active_realtime/Services/lawAuthService.dart';
import 'package:khuza_active_realtime/Widgets/button.dart';
import 'package:khuza_active_realtime/Widgets/textField.dart';
import 'package:khuza_active_realtime/law_enforce/law_portal.dart';
import 'package:provider/provider.dart';

class LawLoginPage extends StatefulWidget {
  const LawLoginPage({super.key});

  @override
  State<LawLoginPage> createState() => _AdminState();
}

class _AdminState extends State<LawLoginPage> {
  TextEditingController adminEmailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  @override
  void initState() {
    super.initState();

    // Load the grants only once when the widget is initialized
    Future.microtask(() {
      Provider.of<AuthLawProvider>(context, listen: false);
    });
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthLawProvider>(context);
    return Scaffold(
        body: Stack(children: [
      Container(
        //   decoration: const BoxDecoration(
        //     image: DecorationImage(
        //       image: AssetImage('images/logo.png'),
        //       fit: BoxFit.cover,
        //     ),
        //   ),
        // ),
        // Positioned.fill(
        //   child: BackdropFilter(
        //     filter: ImageFilter.blur(sigmaX: 90.0, sigmaY:98.0)),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xff613FE5), Color(0xffD0C3FF)],
          ),
        ),
      ),
      Center(
        child: authProvider.isLoading
            ? const CircularProgressIndicator()
            : SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      globalTextField(
                        controller: adminEmailController,
                        label: "Email",
                        icon: const Icon(Icons.person_2_outlined),
                        isPassword: false,
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      globalTextField(
                        //isPassword: true,
                        controller: passwordController,
                        label: "Password",
                        icon: const Icon(Icons.fingerprint_outlined),
                        isPassword: false,
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      ElevatedButton(
                        style: loginButton,
                        onPressed: () async {
                          try {
                            String result = await authProvider.loginlaw(
                                adminEmailController, passwordController);
                            if (result == 'OK') {
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const LawPortal(),
                                ),
                              );
                            } else {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Log in Status : $result'),
                                  backgroundColor: Colors.grey,
                                ),
                              );
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => MultiProvider(
                                    providers: [
                                      ChangeNotifierProvider(
                                        create: (_) => AuthLawProvider(),
                                      ),
                                    ],
                                    child: const LawPortal(),
                                  ),
                                ),
                              );
                            }
                          } catch (error) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(' $error!'),
                                backgroundColor: Colors.red,
                              ),
                            );
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) => MultiProvider(
                                  providers: [
                                    ChangeNotifierProvider(
                                      create: (_) => AuthLawProvider(),
                                    ),
                                  ],
                                  child: const LawPortal(),
                                ),
                              ),
                            );
                          }
                        },
                        child: const Text(
                          'Login',
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        ),
                      ),
                      const Text('or'),
                      ElevatedButton(
                        style: registerButton,
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const RegisterScreen(),
                            ),
                          );
                        },
                        child: const Text(
                          'Back',
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
      ),
    ]));
  }
}
