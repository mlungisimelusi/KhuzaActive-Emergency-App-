import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:khuza_active_realtime/Model/resident.dart';

class ResidentProvider extends ChangeNotifier {
  final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  Future<String> addResident(
    TextEditingController emailController,
    TextEditingController phoneNumberController,
    TextEditingController lastNameContoller,
    TextEditingController firstNameController,
    TextEditingController streetNameController,
    TextEditingController idNumberController,
    TextEditingController passwordController,
    TextEditingController suburbController,
    TextEditingController cityController,
    TextEditingController provinceController,
  ) async {
    try {
      _setLoading(true);
      // Get current user ID
      User? currentUser = _auth.currentUser;
      if (currentUser == null) {
        _setLoading(false);
        return "NOT OK"; // Return NOT OK if the user is not authenticated
      }

      String residentId =currentUser.uid; // Use the current user's ID as residentId

      Resident resident = Resident(
          ResidentId: residentId,
          FirstName: firstNameController.text,
          Email: emailController.text,
          LastName: lastNameContoller.text,
          StreetName: streetNameController.text,
          HouseNumber: idNumberController.text,
          City: cityController.text,
          Suburb : suburbController.text,
          password: passwordController.text,
          Province: provinceController.text,
          PhoneNumber: phoneNumberController.text);
      await _databaseReference
          .child('Resident/$residentId')
          .set(resident.toMap());

      notifyListeners();
      _setLoading(false);
      return "OK";
    } catch (e) {
      _setLoading(false);
      print('Error adding resident: $e');
      return "NOT OK";
    }
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }


}
