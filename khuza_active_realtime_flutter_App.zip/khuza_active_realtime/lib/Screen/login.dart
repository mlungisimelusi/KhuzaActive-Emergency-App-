import 'package:flutter/material.dart';
import 'package:khuza_active_realtime/Screen/forgot_password.dart';
import 'package:khuza_active_realtime/Screen/map_page.dart';
import 'package:khuza_active_realtime/Screen/register.dart';
import 'package:khuza_active_realtime/Services/authService.dart';
import 'package:khuza_active_realtime/Widgets/button.dart';
import 'package:khuza_active_realtime/Widgets/textField.dart';
import 'package:provider/provider.dart';

class LogInScreen extends StatefulWidget {
  const LogInScreen({super.key});

  @override
  State<LogInScreen> createState() => _LogInScreenState();
}

class _LogInScreenState extends State<LogInScreen> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  @override
  void initState() {
    super.initState();

    // Load the grants only once when the widget is initialized
    Future.microtask(() {
      Provider.of<AuthProvider>(context, listen: false);
    });
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);

    return Scaffold(
      body: Center(
        child: authProvider.isLoading
            ? const CircularProgressIndicator()
            : SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Image(
                        image: AssetImage('images/logo.png'),
                        width: 850,
                        height: 500,
                      ),
                      const SizedBox(height: 20),
                      globalTextField(
                        controller: emailController,
                        label: "Email",
                        icon: const Icon(Icons.person_2_outlined),
                        isPassword: false,
                      ),
                      const SizedBox(height: 20),
                      globalTextField(
                        controller: passwordController,
                        label: "Password",
                        icon: const Icon(Icons.fingerprint_outlined),
                        isPassword: true, // Ensure password field hides input
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        style: loginButton,
                        onPressed: () async {
                          try {
                            String result = await authProvider.loginUser(
                                emailController, passwordController);
                            if (result == 'OK') {
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const MapPage(),
                                ),
                              );
                            } else {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Log in Status : $result'),
                                  backgroundColor: Colors.red,
                                ),
                              );
                            }
                          } catch (error) {
                            // Catch specific errors (network, invalid credentials, etc.)
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('Login failed: $error'),
                                backgroundColor: Colors.red,
                              ),
                            );
                          }
                        },
                        child: const Text(
                          'Login',
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        ),
                      ),
                      const SizedBox(height: 5),
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const ForgotPassword()),
                          );
                        },
                        child: const Text(
                          "Forgot Password?",
                          style: TextStyle(
                            color: Color(0xFF8c8e98),
                            fontSize: 18.0,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Text('or'),
                      const SizedBox(height: 10),
                      ElevatedButton(
                        style: registerButton,
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const RegisterScreen(),
                            ),
                          );
                        },
                        child: const Text(
                          'Register',
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}
