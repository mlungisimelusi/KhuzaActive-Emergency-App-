import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AuthAdminProvider extends ChangeNotifier {
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  final FirebaseAuth _auth2 = FirebaseAuth.instance;

  Future<String> loginAdmin(TextEditingController adminEmailController,
      TextEditingController passwordController) async {
    String adminEmail = adminEmailController.text.trim();
    String password = passwordController.text.trim();

    if (adminEmail.isEmpty || password.isEmpty) {
      return 'Email and password cannot be empty';
    }

    _setLoading(true);

    try {
      await Future.delayed(const Duration(seconds: 2));
      UserCredential response = await FirebaseAuth.instance
          .signInWithEmailAndPassword(email: adminEmail, password: password);

      if (response.user != null) {
        _setLoading(false);
        return 'OK';
      } else {
        _setLoading(false);
        return 'NOT OK';
      }
    } catch (e) {
      _setLoading(false);
      print("Login failed : $e");
      return 'NOT';
    }
  }

  Future<String> registerAdmin(TextEditingController adminEmailController,
      TextEditingController passwordController) async {
    String adminEmail = adminEmailController.text.trim();
    String password = passwordController.text.trim();

    if (adminEmail.isEmpty || password.isEmpty) {
      return 'Email and password cannot be empty';
    }

    _setLoading(true);

    try {
      UserCredential userCredential =
          await _auth2.createUserWithEmailAndPassword(
        email: adminEmail,
        password: password,
      );

      User? user = userCredential.user;
      if (user != null && !user.emailVerified) {
        await user.sendEmailVerification();
      }

      _setLoading(false);
      return 'OK';
    } catch (e) {
      _setLoading(false);
      print('Registration failed: $e');
      return 'NOT OK';
    }
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
}
