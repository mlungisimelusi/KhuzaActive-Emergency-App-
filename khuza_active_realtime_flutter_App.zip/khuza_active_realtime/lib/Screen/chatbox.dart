// chatbot_screen.dart
import 'package:flutter/material.dart';

class ChatBotScreen extends StatefulWidget {
  const ChatBotScreen({super.key});

  @override
  _ChatBotScreenState createState() => _ChatBotScreenState();
}

class _ChatBotScreenState extends State<ChatBotScreen> {
  List<Map<String, String>> messages = [];
  List<String> questions = [
    "How do I report a crime?",
    "What types of crimes can I report?",
    "Can I remain anonymous when reporting?",
    "How does the app help keep the community safe?",
    "How do I view safety tips?",
    "What should I do if I witness a crime?",
    "How can I check the status of my report?",
  ];

  void handleQuestionClick(String question) {
    setState(() {
      messages.add({"user": question});
      messages.add({"bot": getBotResponse(question)});
    });
  }

  String getBotResponse(String question) {
    // Simple predefined responses for each question
    switch (question) {
      case "How do I report a crime?":
        return "To report a crime, go to the 'Submit Crime Report' section in the app and fill out the necessary details.";
      case "What types of crimes can I report?":
        return "You can report various crimes such as theft, assault, vandalism, and more using the 'Submit Crime Report' feature.";
      case "Can I remain anonymous when reporting?":
        return "Yes, you can choose to report a crime anonymously by selecting 'Report as Anonymous' in the crime reporting form.";
      case "How does the app help keep the community safe?":
        return "The app helps by allowing users to report crimes quickly, notifying law enforcement, and providing safety tips.";
      case "How do I view safety tips?":
        return "You can view safety tips by visiting the 'Admin Dashboard' where crime awareness and safety tips are shared regularly.";
      case "What should I do if I witness a crime?":
        return "If you witness a crime, stay safe and report the incident using the app. Provide as much detail as possible.";
      case "How can I check the status of my report?":
        return "To check the status of your report, go to the 'View Reports' section in the app to track updates.";
      default:
        return "I'm here to help with any crime-related questions. Please choose from the available options.";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Frequently Asked Questions'),
        backgroundColor: Colors.blueGrey.shade50,
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: ListView.builder(
              itemCount: messages.length,
              itemBuilder: (context, index) {
                String key = messages[index].keys.first;
                String message = messages[index][key]!;
                return Container(
                  alignment: key == "user"
                      ? Alignment.centerRight
                      : Alignment.centerLeft,
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: key == "user" ? Colors.blue[100] : Colors.grey[200],
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(message, style: const TextStyle(fontSize: 16)),
                  ),
                );
              },
            ),
          ),
          // Display predefined questions
          Container(
            padding: const EdgeInsets.all(10),
            color: Colors.blueGrey.shade50,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Select a question to get more information:",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 10,
                  children: questions.map((question) {
                    return GestureDetector(
                      onTap: () => handleQuestionClick(question),
                      child: Chip(
                        label: Text(question),
                        backgroundColor: Colors.blue.shade100,
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
