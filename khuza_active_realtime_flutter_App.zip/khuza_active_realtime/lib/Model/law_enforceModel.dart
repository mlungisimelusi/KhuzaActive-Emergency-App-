class LawEnforce {
  String lawEnforceId;
  String password;
  String lawEnforceEmail;

  LawEnforce({
    required this.lawEnforceId,
    required this.password,
    required this.lawEnforceEmail,
  });

  Map<String, dynamic> toMap() => {
        'LawEnforceId': lawEnforceId,
        'Password': password,
        'Email': lawEnforceEmail,
      };

  factory LawEnforce.fromMap(Map<dynamic, dynamic> data) {
    return LawEnforce(
      lawEnforceId: data['LawEnforceId'] ?? '',
      lawEnforceEmail: data['LawEnforceEmail'] ?? '',
      password: data['Password'] ?? '',
    );
  }
}
