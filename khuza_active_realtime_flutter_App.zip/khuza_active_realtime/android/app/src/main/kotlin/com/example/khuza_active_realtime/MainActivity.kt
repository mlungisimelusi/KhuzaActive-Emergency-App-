package com.example.khuza_active_realtime

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
