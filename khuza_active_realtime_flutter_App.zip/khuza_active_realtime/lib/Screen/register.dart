import 'package:flutter/material.dart';
import 'package:khuza_active_realtime/Screen/login.dart';
import 'package:khuza_active_realtime/Services/lawAuthService.dart';
import 'package:khuza_active_realtime/Services/law_Enforce.dart';
import 'package:khuza_active_realtime/admin_panel/admin.dart';
import 'package:khuza_active_realtime/Screen/registerResident.dart';
import 'package:khuza_active_realtime/Services/adminAuthService.dart';
import 'package:khuza_active_realtime/Services/adminService.dart';
import 'package:khuza_active_realtime/Services/authService.dart';
import 'package:khuza_active_realtime/Services/residentService.dart';
import 'package:khuza_active_realtime/Widgets/box.dart';
import 'package:khuza_active_realtime/Widgets/button.dart';
import 'package:khuza_active_realtime/law_enforce/law_login_page.dart';
import 'package:provider/provider.dart';

class RegisterScreen extends StatelessWidget {
  const RegisterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const Image(
                image: AssetImage('images/droney.png'),
                width: 950,
                height: 400,
              ),
              const SizedBox(
                height: 10,
              ),
              const Text(
                'Stay Safe Stay Alert',
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    fontStyle: FontStyle.italic,
                    color: Colors.blue),
              ),
              const SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  myBox(
                    name: 'Resident',
                    color: const Color.fromRGBO(226, 232, 254, 100),
                    icon: const Icon(
                      Icons.house,
                      size: 65,
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => MultiProvider(providers: [
                            ChangeNotifierProvider(
                              create: (_) => AuthProvider(),
                            ),
                            ChangeNotifierProvider(
                              create: (_) => ResidentProvider(),
                            ),
                          ], child: const ResidentRegisterScreen()),
                        ),
                      );
                    },
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  myBox(
                    name: 'Law Enforcement',
                    color: const Color.fromRGBO(145, 179, 251, 100),
                    icon: const Icon(
                      Icons.security,
                      size: 70,
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => MultiProvider(providers: [
                            ChangeNotifierProvider(
                              create: (_) => AuthLawProvider(),
                            ),
                            ChangeNotifierProvider(
                              create: (_) => LawEnforceProvider(),
                            ),
                          ], child: const LawLoginPage()),
                        ),
                      );
                    },
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              ElevatedButton(
                style: loginButton,
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => MultiProvider(providers: [
                        ChangeNotifierProvider(
                          create: (_) => AuthAdminProvider(),
                        ),
                        ChangeNotifierProvider(
                          create: (_) => AdminProvider(),
                        ),
                      ], child: const Admin()),
                    ),
                  );
                },
                child: const Text(
                  'Administrator',
                  style: TextStyle(color: Colors.white, fontSize: 25),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              ElevatedButton(
                style: registerButton,
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const LogInScreen()));
                },
                child: const Text(
                  'Back',
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
