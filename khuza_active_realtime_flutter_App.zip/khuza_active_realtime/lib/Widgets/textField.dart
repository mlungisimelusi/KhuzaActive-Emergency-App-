import 'package:flutter/material.dart';

class globalTextField extends StatelessWidget {
  const globalTextField({
    super.key,
    required this.controller,
    required this.label,
    required this.icon,
    required this.isPassword,
    // required this.isPassword
  });

  final TextEditingController controller;
  final String label;
  final Icon icon;
  final bool isPassword;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      obscureText: isPassword,
      decoration: InputDecoration(
        enabledBorder: OutlineInputBorder(
            borderSide:
                const BorderSide(color: Color.fromRGBO(226, 232, 254, 100)),
            borderRadius: BorderRadius.circular(20)),
        labelText: label,
        prefixIcon: icon,
      ),
    );
  }
}
