import 'package:flutter/material.dart';
import 'package:khuza_active_realtime/Screen/map_page.dart';
import 'package:khuza_active_realtime/Services/authService.dart';
import 'package:khuza_active_realtime/Services/residentService.dart';
import 'package:khuza_active_realtime/Validation/validation.dart';
import 'package:khuza_active_realtime/Widgets/button.dart';
import 'package:khuza_active_realtime/Widgets/textField.dart';
import 'package:provider/provider.dart';

class ResidentRegisterScreen extends StatefulWidget {
  const ResidentRegisterScreen({super.key});

  @override
  State<ResidentRegisterScreen> createState() => _ResidentRegisterScreenState();
}

class _ResidentRegisterScreenState extends State<ResidentRegisterScreen> {
  TextEditingController emailController = TextEditingController();
  TextEditingController phoneNumberController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController lastNameContoller = TextEditingController();
  TextEditingController firstNameController = TextEditingController();
  TextEditingController idNumberController = TextEditingController();
  TextEditingController suburbController = TextEditingController();
  TextEditingController streetNameController = TextEditingController();
  TextEditingController cityController = TextEditingController();
  TextEditingController provinceController = TextEditingController();
  late MyValidator validator;
  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      Provider.of<AuthProvider>(context, listen: false);
    });
    Future.microtask(() {
      Provider.of<ResidentProvider>(context, listen: false);
    });
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final residentProvider = Provider.of<ResidentProvider>(context);
    return Scaffold(
      appBar: AppBar(
        leading: const Icon(Icons.home_filled),
        title: const Text('Resident Hub'),
        backgroundColor: const Color.fromRGBO(226, 232, 254, 100),
      ),
      body: Center(
        child: authProvider.isLoading || residentProvider.isLoading
            ? const CircularProgressIndicator()
            : SingleChildScrollView(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      globalTextField(
                        controller: firstNameController,
                        label: 'First Name',
                        icon: const Icon(Icons.person), isPassword: false,
                      ),
                      const SizedBox(height: 10),
                      globalTextField(
                        controller: lastNameContoller,
                        label: 'Last Name',
                        icon: const Icon(Icons.person), isPassword: false,
                      ),
                      const SizedBox(height: 10),
                      globalTextField(
                        controller: streetNameController,
                        label: 'Street Name',
                        icon: const Icon(Icons.streetview), isPassword: false,
                      ),
                      const SizedBox(height: 10),
                      globalTextField(
                        controller: idNumberController,
                        label: 'House Number',
                        icon: const Icon(Icons.card_membership), isPassword: false,
                      ),
                      const SizedBox(height: 10),
                      globalTextField(
                        controller: suburbController,
                        label: 'Suburb',
                        icon: const Icon(Icons.location_city), isPassword: false,
                      ),
                      const SizedBox(height: 10),
                      globalTextField(
                        controller: cityController,
                        label: 'City',
                        icon: const Icon(Icons.location_city), isPassword: false,
                      ),
                      const SizedBox(height: 10),
                      globalTextField(
                        controller: provinceController,
                        label: 'Province',
                        icon: const Icon(Icons.map), isPassword: false,
                      ),
                      const SizedBox(height: 10),
                      globalTextField(
                        controller: phoneNumberController,
                        label: 'Phone Number',
                        icon: const Icon(Icons.phone), isPassword: false,
                      ),
                      const SizedBox(height: 10),
                      globalTextField(
                        controller: emailController,
                        label: 'Email Address',
                        icon: const Icon(Icons.email), isPassword: false,
                      ),
                      const SizedBox(height: 10),
                      globalTextField(
                        controller: passwordController,
                        label: 'Password',
                        icon: const Icon(Icons.lock), isPassword: true,
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      ElevatedButton(
                          style: registerButton,
                          onPressed: () async {
                            try {
                              String result = await authProvider.registerUser(
                                  emailController, passwordController);
                              if (result == 'OK') {
                                String response = await authProvider.loginUser(
                                    emailController, passwordController);
                                if (response == 'OK') {
                                  String residentresponse =
                                      await residentProvider.addResident(
                                          emailController,
                                          phoneNumberController,
                                          lastNameContoller,
                                          firstNameController,
                                          passwordController,
                                          streetNameController,
                                          idNumberController,
                                          suburbController,
                                          cityController,
                                          provinceController);
                                  if (residentresponse == 'OK') {
                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => const MapPage(),
                                      ),
                                    );
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text(
                                            ' Could Not Creat Resident Profile!'),
                                        backgroundColor: Colors.red,
                                      ),
                                    );
                                  }
                                } else {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(' Authentication Failed!'),
                                      backgroundColor: Colors.red,
                                    ),
                                  );
                                }
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content:
                                        Text(' Could Not register a user!'),
                                    backgroundColor: Colors.red,
                                  ),
                                );
                              }
                            } catch (error) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(' $error!'),
                                  backgroundColor: Colors.red,
                                ),
                              );
                            }
                          },
                          child: const Text(
                            'Register',
                            style: TextStyle(color: Colors.white, fontSize: 20),
                          )),
                      const SizedBox(
                        height: 10,
                      ),
                      ElevatedButton(
                        style: registerButton,
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: const Text(
                          'Back',
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}
