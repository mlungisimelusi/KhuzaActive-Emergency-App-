class MyValidator {
  //Empty Text Validation
  static String? validationEmptyText(String? firstName, String? value) {
    if (value == null || value.isEmpty) {
      return '$firstName is required.';
    }
    return null;
  }

  static String? validateSurname(String? lastName, String? value) {
    if (value == null || value.isEmpty) {
      return '$lastName is required.';
    }
    return null;
  }

  static String? validationCompanyName(String? CompanyName, String? value) {
    if (value == null || value.isEmpty) {
      return '$CompanyName is required.';
    }
    return null;
  }

  static String? validationBusinessAddress(String? value) {
    if (value == null || value.isEmpty) {
      return 'Office Address is required.';
    }
    return null;
  }

  static String? validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Email is required';
    }
    //Regular expressionfor email validation

    final emailRegExp = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');

    if (!emailRegExp.hasMatch(value)) {
      return 'Invalid email address.';
    }
    return null;
  }

  static String? validateStaff(String? value) {
    if (value == null ||
        value.isEmpty ||
        !value.trim().endsWith('@staff.com')) {
      return 'Please enter a valid  @staff address';
    }
   
    final emailRegExp = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    if (!emailRegExp.hasMatch(value)) {
      return 'Invalid email address.';
    }
    return null;
  }
  
  static String? validateAdnin(String? value) {
    if (value == null ||
        value.isEmpty ||
        !value.trim().endsWith('@admin.com')) {
      return 'Please enter a valid  @admin email';
    }
   
    final emailRegExp = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    if (!emailRegExp.hasMatch(value)) {
      return 'Invalid email address.';
    }
    return null;
  }

  static String? validatePassword(String? value) {
    if (value == null || value.length < 6) {
      return 'Password is required';
    }
    //Check for uppercase letters
    if (!value.contains(RegExp(r'[A-Z]'))) {
      return 'Password must contain at least one uppercase letter.';
    }
    //Check for numbers
    if (!value.contains(RegExp(r'[0-9]'))) {
      return "Password must contain at least one number.";
    }

    //Check for special characters
    if (!value.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]'))) {
      return 'Password must contain at least one special character.';
    }
    return null;
  }

  static String? validatePhoneNumber(String? value) {
    if (value == null || value.isEmpty) {
      return 'Phone number is required.';
    }
    //Regular expression for phone number validation (assuming a 10 digit SA phone number format)
    final phoneRegExp = RegExp(r'^\d{10}$');

    if (!phoneRegExp.hasMatch(value)) {
      return 'Invalid phone number format (10 digits required).';
    }
    return null;
  }

  static String? validateidNumber(String? value) {
    if (value == null || value.isEmpty) {
      return 'ID number is required.';
    }
    //Regular expression for ID number validation (assuming a 103 digit SA ID number format)
    final phoneRegExp = RegExp(r'^\d{13}$');

    if (!phoneRegExp.hasMatch(value)) {
      return 'Invalid ID number format (13 digits required).';
    }
    return null;
  }
}
