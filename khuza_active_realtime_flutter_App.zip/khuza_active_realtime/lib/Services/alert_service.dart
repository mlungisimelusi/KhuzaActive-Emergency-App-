import 'package:firebase_database/firebase_database.dart';
import 'package:khuza_active_realtime/Model/alert.dart';

class AlertService {
  final DatabaseReference _db = FirebaseDatabase.instance.ref("Alert");

  // Add Alert to Firebase
  Future<void> addAlert(Alert alert) async {
    final newAlertRef = _db.push();
    alert.id = newAlertRef.key; // Assign Firebase ID to alert
    await newAlertRef.set(alert.toJson());
  }

  // Get all Alerts
  Future<List<Alert>> getAllAlerts() async {
    final snapshot = await _db.get();
    if (snapshot.exists) {
      final alerts = <Alert>[];
      for (var child in snapshot.children) {
        alerts.add(Alert.fromJson(Map<String, dynamic>.from(child.value as Map)));
      }
      return alerts;
    }
    return [];
  }

  // Update an existing Alert
  Future<void> updateAlert(Alert alert) async {
    if (alert.id != null) {
      await _db.child(alert.id!).set(alert.toJson());
    }
  }

  // Delete Alert by ID
  Future<void> deleteAlert(String id) async {
    await _db.child(id).remove();
  }
}