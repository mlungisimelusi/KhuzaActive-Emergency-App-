import 'package:flutter/material.dart';

class LawEnforcement extends StatelessWidget {
  const LawEnforcement({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Background color for the app
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        title: const Text('Law Enforcement'),
        backgroundColor: Colors.blueGrey[900],
        elevation: 0,
      ),
      body: Stack(
        children: [
          // Background image (optional)
          Positioned.fill(
            child: Opacity(
              opacity: 0.2,
              child: Image.asset(
                'images/logo.png', // Make sure to add an image in assets
                fit: BoxFit.cover,
              ),
            ),
          ),
          Column(
            children: [
              // Header section
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.blueGrey[900],
                  borderRadius: const BorderRadius.vertical(
                    bottom: Radius.circular(20),
                  ),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.shield, color: Colors.white, size: 40),
                    SizedBox(width: 10),
                    Text(
                      'Law Enforcement',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              // Information card
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  elevation: 5,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Welcome to the Law Enforcement Page!',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w600,
                            color: Colors.blueGrey[800],
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'Here you can find important information, resources, '
                          'and contact details related to law enforcement. Explore '
                          'our services to stay safe and informed.',
                          style: TextStyle(
                              fontSize: 16, color: Colors.blueGrey[600]),
                        ),
                        const SizedBox(height: 20),
                        // Button Section
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            ElevatedButton.icon(
                              onPressed: () {},
                              icon: const Icon(Icons.phone),
                              label: const Text('Contact Us'),
                              style: ElevatedButton.styleFrom(
                                foregroundColor: Colors.white,
                                backgroundColor: Colors.blueGrey[800],
                              ),
                            ),
                            ElevatedButton.icon(
                              onPressed: () {},
                              icon: const Icon(Icons.map),
                              label: const Text('Find a Station'),
                              style: ElevatedButton.styleFrom(
                                foregroundColor: Colors.white,
                                backgroundColor: Colors.blueGrey[800],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              // Additional content
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Resources',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.blueGrey[800],
                      ),
                    ),
                    const SizedBox(height: 10),
                    ListTile(
                      leading:
                          Icon(Icons.local_police, color: Colors.blueGrey[700]),
                      title: const Text('Police Services'),
                      subtitle: const Text('Learn more about local police services.'),
                      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                      onTap: () {},
                    ),
                    ListTile(
                      leading:
                          Icon(Icons.security, color: Colors.blueGrey[700]),
                      title: const Text('Safety Tips'),
                      subtitle: const Text('Discover ways to stay safe.'),
                      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                      onTap: () {},
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
