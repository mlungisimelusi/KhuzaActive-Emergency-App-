import 'package:flutter/material.dart';

class myBox extends StatelessWidget {
  const myBox(
      {super.key,
      required this.name,
      required this.onTap,
      required this.icon,
      required this.color});
  final Function()? onTap;
  final String name;
  final Icon icon;
  final Color color;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 170,
      width: 150,
      child: InkWell(
        onTap: onTap,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(50),
          child: Container(
            decoration: BoxDecoration(color: color),
            child: Align(
              alignment: const Alignment(0.1, 0.1),
              child: icon,
            ),
          ),
        ),
      ),
    );
  }
}
