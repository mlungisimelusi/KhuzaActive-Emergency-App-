import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class AdminCrimeReportsPage extends StatefulWidget {
  const AdminCrimeReportsPage({super.key});

  @override
  _AdminCrimeReportsPageState createState() => _AdminCrimeReportsPageState();
}

class _AdminCrimeReportsPageState extends State<AdminCrimeReportsPage> {
  final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref();
  List<Map<dynamic, dynamic>> post = [];
  List<String> postKeys = []; // List to hold keys of the posts

  @override
  void initState() {
    super.initState();
    fetchCrimeReport();
  }

  Future<void> fetchCrimeReport() async {
    try {
      DatabaseEvent firebaseData =
          await _databaseReference.child('Post').once();
      List<Map<String, dynamic>> firebasePost = [];

      if (firebaseData.snapshot.value != null) {
        final Map<dynamic, dynamic> postsMap =
            firebaseData.snapshot.value as Map<dynamic, dynamic>;

        firebasePost = postsMap.entries.map((entry) {
          final value = entry.value as Map;
          final resident =
              value['Resident'] ?? {}; // Fetch nested ResidentModel if exists

          // Store the unique key for deletion later
          postKeys.add(entry.key.toString());

          return {
            'Title': value['Title'] ?? 'Unknown Crime Type',
            'Description': value['Description'] ?? 'No details provided',
            'Location': value['Location'] ?? 'Unknown location',
            'Date': value['Date'] ?? 'Unknown date',
            'Time': value['Time'] ?? 'Unknown time',
            'UploadPhoto': value['UploadPhoto'], // Handle photo URL if exists
            'ResidentId': resident['ResidentId'] ?? 'Unknown',
            'FirstName': resident['FirstName'] ?? 'Unknown',
            'LastName': resident['LastName'] ?? 'Unknown',
            'Email': resident['Email'] ?? 'Unknown',
            'StreetName': resident['StreetName'] ?? '',
            'Suburb': resident['Suburb'] ?? '',
            'City': resident['City'] ?? '',
            'Province': resident['Province'] ?? '',
          };
        }).toList();
      }

      setState(() {
        post = firebasePost;
      });
    } catch (e) {
      setState(() {
        post = [];
      });
      print("Error fetching posts: $e");
    }
  }

  Future<void> deletePost(String postId) async {
    try {
      await _databaseReference.child('Post/$postId').remove();
      // Remove the deleted post from the local state
      setState(() {
        post.removeAt(postKeys.indexOf(postId));
        postKeys.remove(postId); // Remove the key from the list
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Report deleted successfully!')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error deleting report: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(156, 40, 189, 235),
        title: const Text('Crime Reports'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: post.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: post.length,
              itemBuilder: (context, index) {
                final posts = post[index];
                final postId = postKeys[index]; // Get the corresponding key
                final title = posts['Title'] ?? 'Unknown Title';
                final location = posts['Location'] ?? 'Unknown Location';
                final description = posts['Description'] ?? 'No details';
                final date = posts['Date'] ?? 'Date Unknown';
                final residentName =
                    "${posts['FirstName']} ${posts['LastName']}";
                final uploadPhoto = posts['UploadPhoto'] ?? '';

                return Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Card(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15)),
                    child: ListTile(
                      title: Text(
                        title.toUpperCase(),
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Location: $location"),
                          Text("Details: $description"),
                          Text("Date: $date"),
                          const SizedBox(height: 8),
                          uploadPhoto.isNotEmpty
                              ? Image.network(
                                  uploadPhoto,
                                  fit: BoxFit.cover,
                                  height: 200,
                                  errorBuilder: (context, error, stackTrace) {
                                    return const Text('Error loading image');
                                  },
                                )
                              : const Text('No image available'),
                          Text("Reported by: $residentName"),
                        ],
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          // Confirm deletion
                          showDialog(
                            context: context,
                            builder: (context) {
                              return AlertDialog(
                                title: const Text('Confirm Deletion'),
                                content: const Text(
                                    'Are you sure you want to delete this report?'),
                                actions: [
                                  TextButton(
                                    onPressed: () {
                                      Navigator.of(context)
                                          .pop(); // Close the dialog
                                    },
                                    child: const Text('Cancel'),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      Navigator.of(context)
                                          .pop(); // Close the dialog
                                      deletePost(postId); // Call delete method
                                    },
                                    child: const Text('Delete'),
                                  ),
                                ],
                              );
                            },
                          );
                        },
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
