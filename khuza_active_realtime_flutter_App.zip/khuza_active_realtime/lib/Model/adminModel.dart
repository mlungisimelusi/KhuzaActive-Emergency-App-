class Admin {
  String adminId;
  String password;
  String adminEmail;
 
  
  Admin(
      {required this.adminId,
      required this.password,
      required this.adminEmail,
    });

  Map<String, dynamic> toMap() => {
        'AdminId': adminId,
         'Password': password,
        'Email': adminEmail,
       
      };

  factory Admin.fromMap(Map<dynamic, dynamic> data) {
    return Admin(
        adminId: data['AdminId'] ?? '',
        adminEmail: data['AdminEmail'] ?? '',
       password: data['Password'] ?? '',
      );
  }
}
