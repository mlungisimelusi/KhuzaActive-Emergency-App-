// import 'package:flutter/material.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';

// class TrackingPage extends StatelessWidget {
//   final double latitude;
//   final double longitude;

//   const TrackingPage({
//     super.key,
//     required this.latitude,
//     required this.longitude,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Track Location'),
//         backgroundColor: const Color(0xffD0C3FF),
//       ),
//       body: GoogleMap(
//         initialCameraPosition: CameraPosition(
//           target: LatLng(latitude, longitude),
//           zoom: 15,
//         ),
//         markers: {
//           Marker(
//             markerId: MarkerId('alertLocation'),
//             position: LatLng(latitude, longitude),
//             infoWindow: const InfoWindow(title: 'Alert Location'),
//           ),
//         },
//       ),
//     );
//   }
// }
//Test 2
// import 'package:flutter/material.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';
// import 'package:geolocator/geolocator.dart';

// class TrackingPage extends StatefulWidget {
//   final double latitude;
//   final double longitude;
//   final List<LatLng> routeCoordinates;
//   final Map<String, dynamic> location;

//   const TrackingPage({
//     Key? key,
//     required this.latitude,
//     required this.longitude,
//     required this.routeCoordinates,
//     required this.location,
//   }) : super(key: key);

//   @override
//   _TrackingPageState createState() => _TrackingPageState();
// }

// class _TrackingPageState extends State<TrackingPage> {
//   late GoogleMapController _mapController;
//   late LatLng _userLocation;
//   late LatLng _alertLocation;
//   Set<Marker> _markers = {};
//   Set<Polyline> _polylines = {};

//   @override
//   void initState() {
//     super.initState();
//     _userLocation = LatLng(widget.latitude, widget.longitude);
//     _alertLocation = LatLng(widget.latitude, widget.longitude);

//     // Add markers for user and alert locations
//     _markers.add(Marker(
//       markerId: MarkerId("user"),
//       position: _userLocation,
//       infoWindow: InfoWindow(title: "Your Location"),
//     ));

//     _markers.add(Marker(
//       markerId: MarkerId("alert"),
//       position: _alertLocation,
//       infoWindow: InfoWindow(title: "Alert Location"),
//     ));

//     // Add polyline from user to alert location
//     _polylines.add(Polyline(
//       polylineId: PolylineId("route"),
//       visible: true,
//       points: widget.routeCoordinates,
//       width: 5,
//       color: Colors.blue,
//     ));
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("${widget.location['ResidentName']} - Tracking"),
//         backgroundColor: Colors.teal,
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back),
//           onPressed: () => Navigator.pop(context),
//         ),
//       ),
//       body: GoogleMap(
//         initialCameraPosition: CameraPosition(
//           target: _userLocation,
//           zoom: 14,
//         ),
//         markers: _markers,
//         polylines: _polylines,
//         onMapCreated: (GoogleMapController controller) {
//           _mapController = controller;
//         },
//         myLocationEnabled: true,
//         myLocationButtonEnabled: true,
//         zoomControlsEnabled: true,
//       ),
//     );
//   }
// }
/////////
library;

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class TrackingPage extends StatefulWidget {
  final double latitude;
  final double longitude;
  final List<LatLng> routeCoordinates;
  final Map<String, dynamic> location;

  const TrackingPage({
    super.key,
    required this.latitude,
    required this.longitude,
    required this.routeCoordinates,
    required this.location,
  });

  @override
  _TrackingPageState createState() => _TrackingPageState();
}

class _TrackingPageState extends State<TrackingPage> {
  late GoogleMapController _mapController;
  final Set<Marker> _markers = {};
  final Set<Polyline> _polylines = {};

  @override
  void initState() {
    super.initState();
    _markers.add(Marker(
      markerId: const MarkerId('user_location'),
      position: LatLng(widget.latitude, widget.longitude),
      infoWindow: const InfoWindow(title: "User Location"),
    ));

    _markers.add(Marker(
      markerId: const MarkerId('alert_location'),
      position: LatLng(widget.latitude, widget.longitude),
      infoWindow: const InfoWindow(title: "Alert Location"),
    ));

    _polylines.add(Polyline(
      polylineId: const PolylineId('route'),
      points: widget
          .routeCoordinates, // Pass the route coordinates to create polyline
      width: 5,
      color: Colors.blue,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("${widget.location['ResidentName']} - Tracking"),
        backgroundColor: Colors.teal,
      ),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: LatLng(widget.latitude, widget.longitude),
          zoom: 14,
        ),
        markers: _markers,
        polylines: _polylines,
        onMapCreated: (GoogleMapController controller) {
          _mapController = controller;
        },
        myLocationEnabled: true,
        myLocationButtonEnabled: true,
        zoomControlsEnabled: true,
      ),
    );
  }
}

// import 'package:flutter/material.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';

// class TrackingPage extends StatefulWidget {
//   final double latitude;
//   final double longitude;
//   final double defaultLatitude;
//   final double defaultLongitude;
//   final List<LatLng> routeCoordinates;
//   final Map<String, dynamic> location;

//   const TrackingPage({
//     super.key,
//     required this.latitude,
//     required this.longitude,
//     required this.defaultLatitude,
//     required this.defaultLongitude,
//     required this.routeCoordinates,
//     required this.location,
//   });

//   @override
//   _TrackingPageState createState() => _TrackingPageState();
// }

// class _TrackingPageState extends State<TrackingPage> {
//   late GoogleMapController mapController;
//   Set<Marker> _markers = {};
//   Set<Polyline> _polylines = {};

//   @override
//   void initState() {
//     super.initState();
//     // Initialize markers and polyline with provided coordinates
//     _addMarkers();
//     _addPolyline();
//   }

//   // Method to add markers on the map
//   void _addMarkers() {
//     _markers.add(Marker(
//       markerId: MarkerId('user_location'),
//       position: LatLng(widget.latitude, widget.longitude),
//       infoWindow: InfoWindow(title: 'User Location'),
//     ));

//     _markers.add(Marker(
//       markerId: MarkerId('default_location'),
//       position: LatLng(widget.defaultLatitude, widget.defaultLongitude),
//       infoWindow: InfoWindow(title: 'Default Location'),
//     ));
//   }

//   // Method to add polyline on the map
//   void _addPolyline() {
//     _polylines.add(Polyline(
//       polylineId: PolylineId('route'),
//       points: [
//         LatLng(widget.defaultLatitude, widget.defaultLongitude),
//         LatLng(widget.latitude, widget.longitude),
//       ],
//       color: Colors.blue,
//       width: 5,
//     ));
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: const Color(0xffD0C3FF),
//         title: const Text(
//           'Tracking User Location',
//           style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
//         ),
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back, color: Colors.black),
//           onPressed: () => Navigator.pop(context),
//         ),
//       ),
//       body: GoogleMap(
//         initialCameraPosition: CameraPosition(
//           target: LatLng(widget.latitude,
//               widget.longitude), // Start camera at the user’s location
//           zoom: 14,
//         ),
//         markers: _markers,
//         polylines: _polylines,
//         onMapCreated: (GoogleMapController controller) {
//           mapController = controller;
//         },
//       ),
//     );
//   }
// }
