import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AuthLawProvider extends ChangeNotifier {
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  final FirebaseAuth _auth3 = FirebaseAuth.instance;

  Future<String> loginlaw(TextEditingController lawEnforceEmailController,
      TextEditingController passwordController) async {
    String lawEnforceEmail = lawEnforceEmailController.text.trim();
    String password = passwordController.text.trim();

    if (lawEnforceEmail.isEmpty || password.isEmpty) {
      return 'Email and password cannot be empty';
    }

    _setLoading(true);

    try {
      await Future.delayed(const Duration(seconds: 2));
      UserCredential response = await FirebaseAuth.instance
          .signInWithEmailAndPassword(
              email: lawEnforceEmail, password: password);

      if (response.user != null) {
        _setLoading(false);
        return 'OK';
      } else {
        _setLoading(false);
        return 'NOT OK';
      }
    } catch (e) {
      _setLoading(false);
      print("Login failed : $e");
      return 'NOT';
    }
  }

  Future<String> registerlaw(TextEditingController lawEnforceEmailController,
      TextEditingController passwordController) async {
    String lawEnforceEmail = lawEnforceEmailController.text.trim();
    String password = passwordController.text.trim();

    if (lawEnforceEmail.isEmpty || password.isEmpty) {
      return 'Email and password cannot be empty';
    }

    _setLoading(true);

    try {
      UserCredential userCredential =
          await _auth3.createUserWithEmailAndPassword(
        email: lawEnforceEmail,
        password: password,
      );

      User? user = userCredential.user;
      if (user != null && !user.emailVerified) {
        await user.sendEmailVerification();
      }

      _setLoading(false);
      return 'OK';
    } catch (e) {
      _setLoading(false);
      print('Registration failed: $e');
      return 'NOT OK';
    }
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
}
