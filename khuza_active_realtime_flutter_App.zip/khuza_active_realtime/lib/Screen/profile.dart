import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:khuza_active_realtime/Widgets/textField.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final DatabaseReference _databaseRef = FirebaseDatabase.instance.ref();
  final userId = FirebaseAuth.instance.currentUser?.uid;

  final TextEditingController emailController = TextEditingController();
  final TextEditingController phoneNumberController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();
  final TextEditingController firstNameController = TextEditingController();
  final TextEditingController idNumberController = TextEditingController();
  final TextEditingController suburbController = TextEditingController();
  final TextEditingController streetNameController = TextEditingController();
  final TextEditingController cityController = TextEditingController();
  final TextEditingController provinceController = TextEditingController();

  String? profilePhotoUrl;
  final defaultProfilePhoto =
      'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_1280.png';

  @override
  void initState() {
    super.initState();
    _fetchProfileData();
  }

  Future<void> _fetchProfileData() async {
    if (userId != null) {
      DatabaseEvent event = await _databaseRef.child('Resident/$userId').once();

      if (event.snapshot.exists) {
        final data = event.snapshot.value as Map<dynamic, dynamic>;
        firstNameController.text = data['FirstName'] ?? '';
        lastNameController.text = data['LastName'] ?? '';
        streetNameController.text = data['StreetName'] ?? '';
        idNumberController.text = data['IdNumber'] ?? '';
        suburbController.text = data['Suburb'] ?? '';
        cityController.text = data['City'] ?? '';
        provinceController.text = data['Province'] ?? '';
        phoneNumberController.text = data['PhoneNumber'] ?? '';
        emailController.text = data['Email'] ?? '';
        profilePhotoUrl = data['UploadImage'] ?? defaultProfilePhoto;
        setState(() {}); //Ensure UI updates after fetching data
      } else {
        print('No data available for userId: $userId');
      }
    }
  }

  Future<void> _pickImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      await _uploadImage(image);
    }
  }

  Future<void> _uploadImage(XFile image) async {
    if (userId != null) {
      final storageRef =
          FirebaseStorage.instance.ref().child('UploadImage/$userId');
      await storageRef.putFile(File(image.path));

      profilePhotoUrl = await storageRef.getDownloadURL();
      await _databaseRef.child('Resident/$userId').update({
        'UploadImage': profilePhotoUrl,
      });

      setState(() {});
    }
  }

  Future<void> _updateProfileData() async {
    if (userId != null) {
      await _databaseRef.child('Resident/$userId').update({
        'FirstName': firstNameController.text,
        'LastName': lastNameController.text,
        'StreetName': streetNameController.text,
        'IdNumber': idNumberController.text,
        'Suburb': suburbController.text,
        'City': cityController.text,
        'Province': provinceController.text,
        'PhoneNumber': phoneNumberController.text,
        'Email': emailController.text,
      });
      print('Profile updated successfully!');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: GestureDetector(
                  onTap: _pickImage,
                  child: CircleAvatar(
                    radius: 50,
                    backgroundImage: profilePhotoUrl != null
                        ? NetworkImage(profilePhotoUrl!)
                        : NetworkImage(defaultProfilePhoto),
                    backgroundColor: Colors.grey[300],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              globalTextField(
                controller: firstNameController,
                label: 'First Name',
                icon: const Icon(Icons.person),
                isPassword: false,
              ),
              const SizedBox(height: 10),
              globalTextField(
                controller: lastNameController,
                label: 'Last Name',
                icon: const Icon(Icons.person),
                isPassword: false,
              ),
              const SizedBox(height: 10),
              globalTextField(
                controller: streetNameController,
                label: 'Street Name',
                icon: const Icon(Icons.streetview),
                isPassword: false,
              ),
              const SizedBox(height: 10),
              globalTextField(
                controller: idNumberController,
                label: 'House Number',
                icon: const Icon(Icons.card_membership),
                isPassword: false,
              ),
              const SizedBox(height: 10),
              globalTextField(
                controller: suburbController,
                label: 'Suburb',
                icon: const Icon(Icons.location_city),
                isPassword: false,
              ),
              const SizedBox(height: 10),
              globalTextField(
                controller: cityController,
                label: 'City',
                icon: const Icon(Icons.location_city),
                isPassword: false,
              ),
              const SizedBox(height: 10),
              globalTextField(
                controller: provinceController,
                label: 'Province',
                icon: const Icon(Icons.map),
                isPassword: false,
              ),
              const SizedBox(height: 10),
              globalTextField(
                controller: phoneNumberController,
                label: 'Phone Number',
                icon: const Icon(Icons.phone),
                isPassword: false,
              ),
              const SizedBox(height: 10),
              globalTextField(
                controller: emailController,
                label: 'Email Address',
                icon: const Icon(Icons.email),
                isPassword: false,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _updateProfileData,
                child: const Text('Save Profile'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
