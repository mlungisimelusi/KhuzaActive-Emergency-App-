import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:khuza_active_realtime/Model/resident.dart';
import 'package:khuza_active_realtime/Screen/crime_posts.dart';
import 'package:khuza_active_realtime/Screen/crime_reports.dart';
import 'package:khuza_active_realtime/Screen/login.dart';
import 'package:khuza_active_realtime/Screen/profile.dart';
import 'package:khuza_active_realtime/Screen/real_time_alerts.dart';
import 'package:khuza_active_realtime/Screen/resident_postStatus.dart';

class MapPage extends StatefulWidget {
  const MapPage({super.key});

  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  static const _initialCameraPosition = CameraPosition(
    target: LatLng(-27.980659, 26.734961),
    zoom: 15,
  );

  late GoogleMapController _googleMapController;
  //Current Position variable
  LatLng? currentPosition;

  @override
  void dispose() {
    _googleMapController.dispose();
    super.dispose();
  }

//Decoding longitude and latitude to a readable address
  Future<String> getAddressFromCoordinates(
      double latitude, double longitude) async {
    try {
      // Obtain placemarks based on coordinates
      List<Placemark> placemarks =
          await placemarkFromCoordinates(latitude, longitude);

      if (placemarks.isNotEmpty) {
        Placemark place = placemarks.first;

        // Format the address
        String address =
            "${place.street}, ${place.locality}, ${place.administrativeArea}, ${place.country}";
        return address;
      } else {
        return "No address found";
      }
    } catch (e) {
      return "Failed to get address: $e";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.teal,
        leading: IconButton(
          onPressed: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => const LogInScreen()));
          },
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const ProfilePage()));
            },
            icon: const Icon(
              Icons.person,
              color: Colors.white,
            ),
          ),
        ],
        title: const Center(
          child: Text(
            "CRIME MAP",
            style: TextStyle(color: Colors.white),
          ),
        ),
      ),
      body: GoogleMap(
        myLocationButtonEnabled: false,
        zoomControlsEnabled: false,
        initialCameraPosition: _initialCameraPosition,
        onMapCreated: (controller) => _googleMapController = controller,
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.teal,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            buildNavBarItem(
                CupertinoIcons.bell_fill, 0, context, const AlertsPage()),
            const SizedBox(width: 30),
            buildNavBarItem(
                Icons.local_activity, 0, context, const CrimeReportsPage()),
            const SizedBox(width: 100),
            buildNavBarItem(CupertinoIcons.envelope_fill, 0, context,
                const ReportCrimePage()),
            const SizedBox(width: 30),
            buildNavBarItem(
                Icons.feedback, 0, context, const StatusReportsPage()),
            const SizedBox(width: 10),
          ],
        ),
      ),
      floatingActionButton: ClipOval(
        child: Material(
          color: const Color.fromARGB(255, 255, 59, 0),
          elevation: 10,
          child: InkWell(
            onTap: () async {
              // Show confirmation dialog
              final shouldCreateAlert = await showDialog<bool>(
                context: context,
                builder: (context) {
                  return AlertDialog(
                    title: const Text("Alert"),
                    content:
                        const Text("Are you sure you want to make an alert?"),
                    actions: [
                      TextButton(
                        child: const Text("No"),
                        onPressed: () {
                          Navigator.of(context)
                              .pop(false); // Return false if "No" is pressed
                        },
                      ),
                      TextButton(
                        child: const Text("Yes"),
                        onPressed: () {
                          Navigator.of(context)
                              .pop(true); // Return true if "Yes" is pressed
                        },
                      ),
                    ],
                  );
                },
              );

              // If "Yes" was selected, proceed with creating the alert
              if (shouldCreateAlert == true) {
                try {
                  final currentUser = FirebaseAuth.instance.currentUser;

                  //Sending User location
                  Position position = await Geolocator.getCurrentPosition(
                      desiredAccuracy: LocationAccuracy.high);
                  currentPosition =
                      LatLng(position.latitude, position.longitude);
                  //Decoding Long & Lat to a readable address
                  String address = await getAddressFromCoordinates(
                      position.latitude, position.longitude);
                  if (currentUser != null) {
                    // Fetch user info from Realtime Database
                    final residentSnapshot = await FirebaseDatabase.instance
                        .ref('Resident/${currentUser.uid}')
                        .once();
                    if (residentSnapshot.snapshot.value != null) {
                      final residentData = Map<String, dynamic>.from(
                          residentSnapshot.snapshot.value
                              as Map<dynamic, dynamic>);
                      final resident = Resident.fromMap(residentData);
                      // Create a new alert in the 'alerts' node in Realtime Database
                      final alertData = {
                        'ResidentId': currentUser.uid,
                        'Resident': residentData,
                        //'Alert_Address': address,
                        'latitude': position.latitude,
                        'longitude': position.longitude
                      };

                      await FirebaseDatabase.instance
                          .ref('Alert')
                          .push()
                          .set(alertData);

                      // Navigate to AlertsPage with the userInfo
                      Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => const AlertsPage(),
                      ));
                    } else {
                      print("User info not found in the database");
                    }
                  } else {
                    print("No user is logged in");
                  }
                } catch (e) {
                  print("An error occurred: $e");
                }
              }
            },
            child: const SizedBox(
              width: 110,
              height: 110,
              child: Center(
                child: Text(
                  "ALERT",
                  style: TextStyle(
                    fontSize: 30,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}

Widget buildNavBarItem(
    IconData icon, int index, BuildContext context, Widget destinationPage) {
  return InkWell(
    onTap: () {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => destinationPage),
      );
    },
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon),
      ],
    ),
  );
}
