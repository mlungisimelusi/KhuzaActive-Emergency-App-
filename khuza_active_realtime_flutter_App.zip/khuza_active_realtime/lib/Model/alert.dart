class Alert {
  String? id;
  double latitude;
  double longitude;

  Alert({this.id, required this.latitude, required this.longitude});

  // Convert from Firebase response to Alert object
  factory Alert.fromJson(Map<String, dynamic> json) {
    return Alert(
      id: json['id'],
      latitude: json['latitude'] as double,
      longitude: json['longitude'],
    );
  }

  // Convert Alert object to JSON for Firebase storage
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'latitude': latitude,
      'longitude': longitude,
    };
  }
}