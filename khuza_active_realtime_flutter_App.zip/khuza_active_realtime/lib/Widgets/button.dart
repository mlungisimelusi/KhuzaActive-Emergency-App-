import 'package:flutter/material.dart';
import 'package:khuza_active_realtime/Widgets/color.dart';

final ButtonStyle loginButton = ElevatedButton.styleFrom(
  minimumSize: const Size(320, 50),
  backgroundColor: purple,
  elevation: 0,
);
final ButtonStyle registerButton = ElevatedButton.styleFrom(
  minimumSize: const Size(320, 50),
  backgroundColor: blue,
  elevation: 0,
);
final ButtonStyle backAdminButton = ElevatedButton.styleFrom(
  minimumSize: const Size(320, 50),
  backgroundColor: green,
  elevation: 0,
);
