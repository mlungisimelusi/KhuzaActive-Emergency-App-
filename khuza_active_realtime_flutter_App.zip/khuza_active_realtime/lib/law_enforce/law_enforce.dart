import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:khuza_active_realtime/law_enforce/track_location.dart';
 
class AdminPanel extends StatefulWidget {
  const AdminPanel({super.key});

  @override
  _AdminPanelState createState() => _AdminPanelState();
}

class _AdminPanelState extends State<AdminPanel> {
  final databaseReference = FirebaseDatabase.instance.ref();
  List<Map<String, dynamic>> locations = [];
  List<String> locationKeys = []; // To store keys of each location

  @override
  void initState() {
    super.initState();
    _fetchLocations();
  }

  void _fetchLocations() {
    databaseReference.child("Alert").onValue.listen((event) {
      final data = event.snapshot.value;

      if (data != null) {
        locations.clear();
        locationKeys.clear();

        if (data is Map) {
          data.forEach((key, value) {
            if (value is Map) {
              locations.add(Map<String, dynamic>.from(value));
              locationKeys.add(key); // Save the key for each location
            }
          });
        }

        setState(() {});
      }
    });
  }

  void _trackLocation(Map<String, dynamic> location) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TrackLocationScreen(location: location),
      ),
    );
  }

  void _deleteLocation(int index) {
    String key = locationKeys[index];
    databaseReference.child("Alert/$key").remove().then((_) {
      setState(() {
        locations.removeAt(index);
        locationKeys.removeAt(index);
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Location deleted successfully')),
      );
    }).catchError((error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error deleting location: $error')),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Panel'),
      ),
      body: ListView.builder(
        itemCount: locations.length,
        itemBuilder: (context, index) {
          final loc = locations[index];
          return ListTile(
            title: Text('Lat: ${loc['latitude']}, Lon: ${loc['longitude']}'),
            subtitle: Text('Timestamp: ${loc['timestamp']}'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.track_changes),
                  onPressed: () => _trackLocation(loc),
                ),
                IconButton(
                  icon: const Icon(Icons.delete),
                  color: Colors.red,
                  onPressed: () => _deleteLocation(index),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}