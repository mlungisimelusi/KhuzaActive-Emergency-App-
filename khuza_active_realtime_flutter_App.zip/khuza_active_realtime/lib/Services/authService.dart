import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AuthProvider extends ChangeNotifier {
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<String> loginUser(TextEditingController emailController,
      TextEditingController passwordController) async {
    String email = emailController.text.trim();
    String password = passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      return 'Email and password cannot be empty';
    }

    _setLoading(true);

    try {
      await Future.delayed(const Duration(seconds: 2));
      UserCredential response = await FirebaseAuth.instance
          .signInWithEmailAndPassword(email: email, password: password);

      if (response.user != null) {
        _setLoading(false);
        return 'OK';
      } else {
        _setLoading(false);
        return 'NOT OK';
      }
    } catch (e) {
      _setLoading(false);
      print("Login failed : $e");
      return 'NOT';
    }
  }

  Future<String> registerUser(TextEditingController emailController,
      TextEditingController passwordController) async {
    String email = emailController.text.trim();
    String password = passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      return 'Email and password cannot be empty';
    }

    _setLoading(true);

    try {
      UserCredential userCredential =
          await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      User? user = userCredential.user;
      if (user != null && !user.emailVerified) {
        await user.sendEmailVerification();
      }

      _setLoading(false);
      return 'OK';
    } catch (e) {
      _setLoading(false);
      print('Registration failed: $e');
      return 'NOT OK';
    }
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
}
