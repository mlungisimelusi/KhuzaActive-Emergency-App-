// import 'package:flutter/material.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';
// import 'package:location/location.dart';

// class LocationTrackingPage extends StatefulWidget {
//   const LocationTrackingPage({super.key});

//   @override
//   _LocationTrackingPageState createState() => _LocationTrackingPageState();
// }

// class _LocationTrackingPageState extends State<LocationTrackingPage> {
//   LocationData? _currentLocation;
//   late GoogleMapController _mapController;
//   late Location _locationService;
//   final Set<Marker> _markers = {};
//   final List<LatLng> _routeCoordinates = []; // To store the path coordinates
//   final Set<Polyline> _polylines = {}; // Set of polylines

//   @override
//   void initState() {
//     super.initState();
//     _locationService = Location();
//     _initializeLocation();
//   }

//   void _initializeLocation() async {
//     final hasPermission = await _locationService.requestPermission();
//     if (hasPermission == PermissionStatus.granted) {
//       final locationData = await _locationService.getLocation();
//       setState(() {
//         _currentLocation = locationData;
//         _routeCoordinates.add(LatLng(locationData.latitude!,
//             locationData.longitude!)); // Add initial location to route
//       });
//       _locationService.onLocationChanged.listen((newLoc) {
//         setState(() {
//           _currentLocation = newLoc;
//           _routeCoordinates.add(LatLng(newLoc.latitude!,
//               newLoc.longitude!)); // Add new location to route
//           _updateMarker(newLoc);
//           _updatePolyline(); // Update the polyline with new location
//         });
//         _mapController.animateCamera(CameraUpdate.newLatLng(
//           LatLng(newLoc.latitude!, newLoc.longitude!),
//         ));
//       });
//     }
//   }

//   void _updateMarker(LocationData location) {
//     final marker = Marker(
//       markerId: const MarkerId("user_location"),
//       position: LatLng(location.latitude!, location.longitude!),
//       infoWindow: const InfoWindow(title: "User's Location"),
//     );
//     setState(() {
//       _markers.add(marker);
//     });
//   }

//   void _updatePolyline() {
//     final polyline = Polyline(
//       polylineId: const PolylineId("user_route"),
//       points: _routeCoordinates,
//       color: Colors.blueAccent,
//       width: 5,
//     );
//     setState(() {
//       _polylines.clear(); // Clear old polylines
//       _polylines.add(polyline); // Add updated polyline with new route
//     });
//   }

//   void _centerOnUser() {
//     if (_currentLocation != null) {
//       _mapController.animateCamera(
//         CameraUpdate.newLatLng(
//           LatLng(_currentLocation!.latitude!, _currentLocation!.longitude!),
//         ),
//       );
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("User Location Tracking"),
//         backgroundColor: Colors.blueAccent,
//       ),
//       body: Stack(
//         children: [
//           GoogleMap(
//             initialCameraPosition: CameraPosition(
//               target: _currentLocation != null
//                   ? LatLng(
//                       _currentLocation!.latitude!, _currentLocation!.longitude!)
//                   : const LatLng(-26.270760, 28.112268),
//               zoom: 15,
//             ),
//             markers: _markers,
//             polylines: _polylines, // Add the polyline set to the map
//             onMapCreated: (controller) => _mapController = controller,
//             myLocationEnabled: true,
//           ),
//           Positioned(
//             top: 20,
//             left: 20,
//             child: FloatingActionButton(
//               onPressed: _centerOnUser,
//               child: const Icon(Icons.my_location),
//             ),
//           ),
//           if (_currentLocation != null)
//             Positioned(
//               bottom: 50,
//               left: 10,
//               right: 10,
//               child: Card(
//                 color: Colors.white,
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(8),
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.all(12.0),
//                   child: Column(
//                     mainAxisSize: MainAxisSize.min,
//                     children: [
//                       const Text(
//                         "Tracking User",
//                         style: TextStyle(
//                             fontWeight: FontWeight.bold, fontSize: 18),
//                       ),
//                       const SizedBox(height: 10),
//                       Text(
//                         "Latitude: ${_currentLocation!.latitude}",
//                         style: const TextStyle(fontSize: 16),
//                       ),
//                       Text(
//                         "Longitude: ${_currentLocation!.longitude}",
//                         style: const TextStyle(fontSize: 16),
//                       ),
//                       Text(
//                         "Last Updated: ${DateTime.now()}",
//                         style: const TextStyle(fontSize: 14, color: Colors.grey),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//         ],
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class LocationTrackingPage extends StatefulWidget {
  const LocationTrackingPage({super.key});

  @override
  _LocationTrackingPageState createState() => _LocationTrackingPageState();
}

class _LocationTrackingPageState extends State<LocationTrackingPage> {
  LocationData? _currentLocation;
  late GoogleMapController _mapController;
  late Location _locationService;
  final Set<Marker> _markers = {};
  final List<LatLng> _routeCoordinates = [];
  final Set<Polyline> _polylines = {};
  final String _apiKey = 'AIzaSyBtXZyJe9CLvZPWXK_EhAxES2nzuunBfM4';

  @override
  void initState() {
    super.initState();
    _locationService = Location();
    _initializeLocation();
  }

  void _initializeLocation() async {
    final hasPermission = await _locationService.requestPermission();
    if (hasPermission == PermissionStatus.granted) {
      final locationData = await _locationService.getLocation();
      setState(() {
        _currentLocation = locationData;
        _routeCoordinates
            .add(LatLng(locationData.latitude!, locationData.longitude!));
      });
      _locationService.onLocationChanged.listen((newLoc) {
        setState(() {
          _currentLocation = newLoc;
        });
        _fetchRoute(LatLng(newLoc.latitude!, newLoc.longitude!));
      });
    }
  }

  // Fetch road-following route and add markers
  Future<void> _fetchRoute(LatLng newPoint) async {
    if (_routeCoordinates.isNotEmpty) {
      final lastPoint = _routeCoordinates.last;
      final url =
          Uri.parse('https://maps.googleapis.com/maps/api/directions/json'
              '?origin=${lastPoint.latitude},${lastPoint.longitude}'
              '&destination=${newPoint.latitude},${newPoint.longitude}'
              '&key=$_apiKey');

      final response = await http.get(url);
      if (response.statusCode == 200) {
        final jsonResponse = json.decode(response.body);
        final List<LatLng> polylinePoints = [];
        if (jsonResponse['routes'] != null &&
            jsonResponse['routes'].isNotEmpty &&
            jsonResponse['routes'][0]['overview_polyline'] != null) {
          String encodedPolyline =
              jsonResponse['routes'][0]['overview_polyline']['points'];
          polylinePoints.addAll(_decodePolyline(encodedPolyline));
        }

        setState(() {
          _routeCoordinates.addAll(polylinePoints);
          _updateMarkers(lastPoint, newPoint, polylinePoints);
          _updatePolyline();
        });
      }
    }
  }

  // Helper method to decode polyline
  List<LatLng> _decodePolyline(String poly) {
    List<LatLng> points = [];
    int index = 0, len = poly.length;
    int lat = 0, lng = 0;

    while (index < len) {
      int b, shift = 0, result = 0;
      do {
        b = poly.codeUnitAt(index++) - 63;
        result |= (b & 0x1F) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlat = (result & 1) != 0 ? ~(result >> 1) : (result >> 1);
      lat += dlat;

      shift = 0;
      result = 0;
      do {
        b = poly.codeUnitAt(index++) - 63;
        result |= (b & 0x1F) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlng = (result & 1) != 0 ? ~(result >> 1) : (result >> 1);
      lng += dlng;

      points.add(LatLng(lat / 1E5, lng / 1E5));
    }
    return points;
  }

  // Update polyline markers (start, end, and waypoints)
  void _updateMarkers(
      LatLng startPoint, LatLng endPoint, List<LatLng> routePoints) {
    final startMarker = Marker(
      markerId: const MarkerId("start_location"),
      position: startPoint,
      infoWindow: const InfoWindow(title: "Start Location"),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
    );

    final endMarker = Marker(
      markerId: const MarkerId("end_location"),
      position: endPoint,
      infoWindow: const InfoWindow(title: "End Location"),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
    );

    setState(() {
      _markers.add(startMarker);
      _markers.add(endMarker);
      // Optional: Add additional markers at specific points along the route
      for (int i = 1; i < routePoints.length - 1; i += 10) {
        // Add markers at intervals
        _markers.add(
          Marker(
            markerId: MarkerId("waypoint_$i"),
            position: routePoints[i],
            icon:
                BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
          ),
        );
      }
    });
  }

  // Draw the updated polyline
  void _updatePolyline() {
    final polyline = Polyline(
      polylineId: const PolylineId("user_route"),
      points: _routeCoordinates,
      color: Colors.blueAccent,
      width: 5,
    );
    setState(() {
      _polylines.clear();
      _polylines.add(polyline);
    });
  }

  void _centerOnUser() {
    if (_currentLocation != null) {
      _mapController.animateCamera(
        CameraUpdate.newLatLng(
          LatLng(_currentLocation!.latitude!, _currentLocation!.longitude!),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("User Location Tracking"),
        backgroundColor: Colors.blueAccent,
      ),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: CameraPosition(
              target: _currentLocation != null
                  ? LatLng(
                      _currentLocation!.latitude!, _currentLocation!.longitude!)
                  : const LatLng(-26.270760, 28.112268),
              zoom: 15,
            ),
            markers: _markers,
            polylines: _polylines,
            onMapCreated: (controller) => _mapController = controller,
            myLocationEnabled: true,
          ),
          Positioned(
            top: 20,
            left: 20,
            child: FloatingActionButton(
              onPressed: _centerOnUser,
              child: const Icon(Icons.my_location),
            ),
          ),
          if (_currentLocation != null)
            Positioned(
              bottom: 50,
              left: 10,
              right: 10,
              child: Card(
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        "Tracking User",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 18),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        "Latitude: ${_currentLocation!.latitude}",
                        style: const TextStyle(fontSize: 16),
                      ),
                      Text(
                        "Longitude: ${_currentLocation!.longitude}",
                        style: const TextStyle(fontSize: 16),
                      ),
                      Text(
                        "Last Updated: ${DateTime.now()}",
                        style:
                            const TextStyle(fontSize: 14, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
