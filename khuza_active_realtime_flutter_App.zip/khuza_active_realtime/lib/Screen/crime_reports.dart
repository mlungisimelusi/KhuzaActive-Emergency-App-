import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:geocoding/geocoding.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:khuza_active_realtime/Model/resident.dart';
import 'package:path/path.dart' as path;
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:image_picker/image_picker.dart';
import 'package:khuza_active_realtime/Screen/crime_posts.dart';
import 'package:geolocator/geolocator.dart';

class ReportCrimePage extends StatefulWidget {
  const ReportCrimePage({super.key});

  @override
  _ReportCrimePageState createState() => _ReportCrimePageState();
}

class _ReportCrimePageState extends State<ReportCrimePage> {
  final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref();
  final TextEditingController descriptionController = TextEditingController();
  final TextEditingController locationController = TextEditingController();
  final TextEditingController titleController = TextEditingController();
  File? _mediaFile;
  bool isUploading = false;
  DateTime selectedDate = DateTime.now();
  TimeOfDay selectedTime = TimeOfDay.now();
  GoogleMapController? _googleMapController;
  LatLng _initialPosition =
      const LatLng(-27.980659, 26.734961); // Default position

  @override
  void dispose() {
    _googleMapController?.dispose();
    descriptionController.dispose();
    locationController.dispose();
    titleController.dispose();
    super.dispose();
  }

  void _recenterMap() {
    if (_googleMapController != null) {
      _googleMapController!.animateCamera(
        CameraUpdate.newCameraPosition(
          CameraPosition(target: _initialPosition, zoom: 15.0),
        ),
      );
    }
  }

  Future<void> _searchAddress() async {
    String address = locationController.text;
    if (address.isEmpty) {
      _showError("Please enter an address to search.");
      return;
    }

    try {
      List<Location> locations = await locationFromAddress(address);
      if (locations.isNotEmpty) {
        Location location = locations.first;
        LatLng target = LatLng(location.latitude, location.longitude);

        _googleMapController?.animateCamera(
          CameraUpdate.newCameraPosition(
            CameraPosition(target: target, zoom: 15.0),
          ),
        );
      } else {
        _showError("No results found for the address.");
      }
    } catch (e) {
      _showError("Could not find the address. Please try again.");
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _getCurrentLocation() async {
    try {
      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high);
      LatLng currentLocation = LatLng(position.latitude, position.longitude);

      // Update the map's initial position to the user's current location
      _initialPosition = currentLocation;

      // Update the text field with the current address
      List<Placemark> placemarks =
          await placemarkFromCoordinates(position.latitude, position.longitude);
      if (placemarks.isNotEmpty) {
        Placemark placemark = placemarks.first;
        String address =
            "${placemark.street}, ${placemark.locality}, ${placemark.postalCode}, ${placemark.country}";
        locationController.text = address; // Set the address in the text field
      }

      _googleMapController?.animateCamera(
        CameraUpdate.newCameraPosition(
          CameraPosition(target: currentLocation, zoom: 15.0),
        ),
      );
    } catch (e) {
      _showError("Could not get current location: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Report Crime',
          style: TextStyle(color: Colors.black),
        ),
        backgroundColor: const Color.fromRGBO(145, 179, 251, 100),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: <Widget>[
                SizedBox(
                  width: 425,
                  height: 300,
                  child: GoogleMap(
                    initialCameraPosition:
                        CameraPosition(target: _initialPosition, zoom: 15.0),
                    onMapCreated: (controller) =>
                        _googleMapController = controller,
                  ),
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: locationController,
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.location_pin),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20)),
                    labelText: 'Add Address',
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                    'Date: ${selectedDate.day}/${selectedDate.month}/${selectedDate.year}'),
                IconButton(
                  icon: const Icon(Icons.calendar_today),
                  onPressed: _selectDate,
                ),
                Text('Time: ${selectedTime.hour}:${selectedTime.minute}'),
                IconButton(
                  icon: const Icon(Icons.access_time),
                  onPressed: _selectTime,
                ),
                const SizedBox(height: 10.0),
                TextFormField(
                  controller: titleController,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30)),
                    labelText: 'Crime Type',
                  ),
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: descriptionController,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30)),
                    labelText: 'Add Details',
                  ),
                  maxLines: 4,
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _pickMedia,
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.camera_alt),
                      SizedBox(width: 8),
                      Text('ADD PHOTOS/VIDEOS'),
                    ],
                  ),
                ),
                if (_mediaFile != null)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 20.0),
                    child: Text(
                        'Media selected: ${path.basename(_mediaFile!.path)}'),
                  ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blueGrey),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: const Text('Cancel',
                          style: TextStyle(color: Colors.white)),
                    ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blueAccent),
                      onPressed: _submitReport,
                      child: isUploading
                          ? const CircularProgressIndicator()
                          : const Text('Submit',
                              style: TextStyle(color: Colors.white)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _getCurrentLocation,
        tooltip: 'Get Current Location',
        child: const Icon(Icons.my_location),
      ),
    );
  }

  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  Future<void> _selectTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: selectedTime,
    );
    if (picked != null && picked != selectedTime) {
      setState(() {
        selectedTime = picked;
      });
    }
  }

  Future<void> _pickMedia() async {
    final ImagePicker picker = ImagePicker();
    final XFile? selectedMedia =
        await picker.pickImage(source: ImageSource.gallery);

    if (selectedMedia != null) {
      setState(() {
        _mediaFile = File(selectedMedia.path);
      });
    }
  }

  Future<void> _submitReport() async {
    final currentUser = FirebaseAuth.instance.currentUser;

    if (titleController.text.isEmpty ||
        descriptionController.text.isEmpty ||
        _mediaFile == null ||
        currentUser == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Please complete all fields and select an image')),
      );
      return;
    }

    setState(() {
      isUploading = true;
    });

    try {
      String fileName = path.basename(_mediaFile!.path);
      Reference storageReference =
          FirebaseStorage.instance.ref().child('Post/$fileName');
      UploadTask uploadTask = storageReference.putFile(_mediaFile!);

      TaskSnapshot snapshot = await uploadTask;
      if (snapshot.state == TaskState.success) {
        String downloadUrl = await snapshot.ref.getDownloadURL();

        final residentSnapshot = await FirebaseDatabase.instance
            .ref('Resident/${currentUser.uid}')
            .once();

        if (residentSnapshot.snapshot.value != null) {
          final residentData = Map<String, dynamic>.from(
            residentSnapshot.snapshot.value as Map<dynamic, dynamic>,
          );
          final resident = Resident.fromMap(residentData);

          String reportId = _databaseReference.child('Post').push().key ?? '';
          await _databaseReference.child('Post/$reportId').set({
            'Title': titleController.text,
            'Description': descriptionController.text,
            'Date': selectedDate.toString(),
            'Time': '${selectedTime.hour}:${selectedTime.minute}',
            'Location': locationController.text,
            'UploadPhoto': downloadUrl,
            'Resident': resident.toMap(),
          });

          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Report submitted successfully!')),
          );

          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const CrimeReportsPage()),
          );
        } else {
          throw Exception("Resident data not found");
        }
      } else {
        throw Exception("Upload failed");
      }
    } catch (e) {}
  }
}
