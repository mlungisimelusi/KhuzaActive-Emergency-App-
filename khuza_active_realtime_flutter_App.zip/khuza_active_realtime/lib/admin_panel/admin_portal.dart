import 'package:flutter/material.dart';
import 'package:khuza_active_realtime/Screen/login.dart';
import 'package:khuza_active_realtime/Widgets/box.dart';
import 'package:khuza_active_realtime/Widgets/button.dart';
import 'package:khuza_active_realtime/admin_panel/admin_alerts.dart';
import 'package:khuza_active_realtime/admin_panel/admin_post.dart';

class AdminPortal extends StatelessWidget {
  const AdminPortal({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar (title:const Text('Administrator Hub'),backgroundColor: const Color(0xFF3ac3cb),),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
           const Text(
                'Stay Safe Stay Alert',
                style: TextStyle(
                    fontSize:20,
                    fontWeight: FontWeight.bold,
                    fontStyle: FontStyle.italic,
                    color: Colors.blue),
              ),
              const SizedBox(height: 40,),
              Column(
                 children: [
                  myBox(
                    name: 'Reports',
                    color: const Color.fromARGB(156, 252, 255, 47),
                    icon: const Icon(
                      Icons.report,
                      size: 70,
                    ),
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => const AdminCrimeReportsPage()));
                    },
                  ),
                  const SizedBox(height: 25,),
                    myBox(
                    name: 'Alerts',
                    color: const Color.fromARGB(156, 72, 238, 169),
                    icon: const Icon(
                      Icons.notifications_active,
                      size: 70,
                    ),
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) =>const AdminAlertsPage()));
                    },
                  ),
                  const SizedBox(height: 25,),
                   ElevatedButton(
                style: registerButton,
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>const LogInScreen()));
                },
                child: const Text(
                  'Back',
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
              ),
                 ]
              )
        ],)
      ),
    );
  }
}