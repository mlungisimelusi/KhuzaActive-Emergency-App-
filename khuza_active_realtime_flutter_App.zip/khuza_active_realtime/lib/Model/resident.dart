class Resident {
  String ResidentId;
  String FirstName;
  String Email;
  String LastName;
  String StreetName;
  String City;
  String Suburb;
  String HouseNumber;
  String Province;
  String PhoneNumber;
  
  Resident(
      {required this.ResidentId,
      required this.FirstName,
      required this.Email,
      required this.Suburb,
      required this.LastName,
      required this.StreetName,
      required this.HouseNumber,
      required this.City,
      required this.Province,
      required this.PhoneNumber, required String password});

  Map<String, dynamic> toMap() => {
        'ResidentId': ResidentId,
        'FirstName': FirstName,
        'Email': Email,
        'LastName': LastName,
        'StreetName': StreetName,
        'IdNumber': HouseNumber,
        'City': City,
        'Province': Province,
        'PhoneNumber': PhoneNumber
      };

//   factory Resident.fromMap(Map<dynamic, dynamic> data) {
//     return Resident(
//         ResidentId: data['ResidentId'] ?? '',
//         FirstName: data['FirstName'] ?? '',
//         LastName: data['LastName'] ?? '',
//         Email: data['Email'] ?? '',
//         StreetName: data['StreetNumber'] ?? '',
//        HouseNumber: data['IdNumber'] ?? '',
//        Suburb: data['Suburb'] ?? '',
//        password: data['Password'] ?? '',
//         City: data['City'] ?? '',
//         Province: data['Province'] ?? '',
//         PhoneNumber: data['PhoneNumber'] ?? '');
//   }
// }
 factory Resident.fromMap(Map<dynamic, dynamic> map) {
    return Resident(
        ResidentId: map['ResidentId'] ?? '',
        FirstName: map['FirstName'] ?? '',
        LastName: map['LastName'] ?? '',
        Email: map['Email'] ?? '',
        StreetName: map['StreetNumber'] ?? '',
       HouseNumber: map['IdNumber'] ?? '',
       Suburb: map['Suburb'] ?? '',
       password: map['Password'] ?? '',
        City:map['City'] ?? '',
        Province:map['Province'] ?? '',
        PhoneNumber:map['PhoneNumber'] ?? '');
  }
}
