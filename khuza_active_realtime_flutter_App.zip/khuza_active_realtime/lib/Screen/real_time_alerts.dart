// import 'package:flutter/material.dart';
// import 'package:firebase_database/firebase_database.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';

// class AlertsPage extends StatefulWidget {
//   const AlertsPage({super.key});

//   @override
//   _AlertsPageState createState() => _AlertsPageState();
// }

// class _AlertsPageState extends State<AlertsPage> {
//   final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref();
//   List<Map<String, dynamic>> alertsList = [];
//   List<Map<String, dynamic>> locations = [];
//   @override
//   void initState() {
//     super.initState();
//     fetchFirebaseData();
//   }

// //Fetch location
//   void _fetchLocations() {
//     _databaseReference.child("Alert").onValue.listen((event) {
//       final data = event.snapshot.value;

//       if (data != null) {
//         locations.clear();

//         if (data is Map) {
//           data.forEach((key, value) {
//             if (value is Map) {
//               final routeCoordinates = (value['routeCoordinates'] as List?)
//                   ?.map((coord) => LatLng(
//                         coord['latitude'],
//                         coord['longitude'],
//                       ))
//                   .toList();

//               locations.add({
//                 "latitude": value['latitude'],
//                 "longitude": value['longitude'],
//                 "Address_Address": value['Alert_Address'],
//                 "routeCoordinates": routeCoordinates ?? [],
//               });
//             }
//           });
//         }

//         setState(() {});
//       }
//     });
//   }

//   // Function to fetch data from Firebase
//   Future<void> fetchFirebaseData() async {
//     try {
//       // Fetch Firebase data
//       DatabaseEvent firebaseData =
//           await _databaseReference.child('Alert').once();
//       List<Map<String, dynamic>> firebaseAlerts = [];
//       if (firebaseData.snapshot.value != null) {
//         final Map<dynamic, dynamic> alertsMap =
//             firebaseData.snapshot.value as Map<dynamic, dynamic>;

//         firebaseAlerts = alertsMap.entries.map((entry) {
//           final value = entry.value as Map;

//           // Extract ResidentId and ResidentModel from the nested structure
//           final resident =
//               value['Resident'] ?? {}; // Fetch the nested ResidentModel

//           return {
//             'ResidentId':
//                 resident['ResidentId'] ?? 'Unknown', // Extract ResidentId
//             'FirstName': resident['FirstName'] ??
//                 'Unknown', // Extract FirstName from ResidentModel
//             'LastName': resident['LastName'] ??
//                 'Unknown', // Extract LastName from ResidentModel
//             'Email': resident['Email'] ??
//                 'Unknown', // Extract Email from ResidentModel
//             'StreetName': resident['StreetName'] ??
//                 'Unknown', // Extract StreetName from ResidentModel
//             'Suburb': resident['Suburb'] ??
//                 'Unknown', // Extract Suburb from ResidentModel
//             'City': resident['City'] ??
//                 'Unknown', // Extract City from ResidentModel
//             'Province': resident['Province'] ?? 'Unknown',
//           };
//         }).toList();
//       }

//       // Update the state with the fetched data
//       setState(() {
//         alertsList = firebaseAlerts;
//       });
//     } catch (e) {
//       // Handle any errors
//       setState(() {
//         alertsList = [];
//       });
//       print("Error fetching alerts: $e");
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: const Color(0xffD0C3FF),
//         title: const Text(
//           'Community Alerts',
//           style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
//         ),
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back, color: Colors.black),
//           onPressed: () => Navigator.pop(context),
//         ),
//       ),
//       body: alertsList.isEmpty
//           ? const Center(
//               child: Text(
//                 'No alerts available',
//                 style: TextStyle(fontSize: 18, color: Colors.grey),
//               ),
//             )
//           : ListView.builder(
//               padding: const EdgeInsets.all(10.0),
//               itemCount: alertsList.length,
//               itemBuilder: (context, index) {
//                 final loc = locations[index];
//                 final resident = alertsList[index];

//                 final residentName =
//                     "${resident['FirstName']} ${resident['LastName']}"
//                         .toUpperCase();
//                 final email = resident['Email'] ?? 'Unknown email';
//                 //
//                 final address = "${loc['Alert_Address']}";

//                 return Padding(
//                   padding: const EdgeInsets.symmetric(vertical: 8.0),
//                   child: Card(
//                     elevation: 5,
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(15),
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.all(16.0),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text(
//                             residentName,
//                             style: const TextStyle(
//                               fontSize: 18,
//                               fontWeight: FontWeight.bold,
//                               color: Colors.teal,
//                             ),
//                           ),
//                           const SizedBox(height: 8),
//                           Row(
//                             children: [
//                               const Icon(Icons.email, color: Colors.grey),
//                               const SizedBox(width: 8),
//                               Text(
//                                 email,
//                                 style: const TextStyle(
//                                   fontSize: 14,
//                                   color: Colors.black87,
//                                 ),
//                               ),
//                             ],
//                           ),
//                           const Divider(height: 20, thickness: 1),
//                           Row(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               const Icon(Icons.location_on, color: Colors.grey),
//                               const SizedBox(width: 8),
//                               Expanded(
//                                 child: Text(
//                                   "Address:  ${address}",
//                                   style: const TextStyle(
//                                     fontSize: 14,
//                                     color: Colors.black87,
//                                   ),
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                 );
//               },
//             ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class AlertsPage extends StatefulWidget {
  const AlertsPage({super.key});

  @override
  _AlertsPageState createState() => _AlertsPageState();
}

class _AlertsPageState extends State<AlertsPage> {
  final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref();
  List<Map<String, dynamic>> alertsList = [];

  @override
  void initState() {
    super.initState();
    fetchFirebaseData();
  }

  Future<void> fetchFirebaseData() async {
    try {
      _databaseReference.child("Alert").onValue.listen((event) {
        final data = event.snapshot.value;
        if (data != null && data is Map) {
          List<Map<String, dynamic>> firebaseAlerts = [];

          data.forEach((key, value) {
            if (value is Map) {
              final resident = value['Resident'] ?? {};

              // Parse routeCoordinates as a list of LatLng objects
              final routeCoordinates =
                  (value['routeCoordinates'] as List<dynamic>?)
                      ?.map((coord) => LatLng(
                            coord['latitude'],
                            coord['longitude'],
                          ))
                      .toList();

              firebaseAlerts.add({
                'ResidentId': resident['ResidentId'] ?? 'Unknown',
                'FirstName': resident['FirstName'] ?? 'Unknown',
                'LastName': resident['LastName'] ?? 'Unknown',
                'Email': resident['Email'] ?? 'Unknown',
                'StreetName': resident['StreetName'] ?? 'Unknown',
                'Suburb': resident['Suburb'] ?? 'Unknown',
                'City': resident['City'] ?? 'Unknown',
                'Province': resident['Province'] ?? 'Unknown',
                'latitude': value['latitude'],
                'longitude': value['longitude'],
                //'Alert_Address': value['Alert_Address'] ?? 'Unknown',
                'routeCoordinates': routeCoordinates ?? [],
              });
            }
          });

          // Update the state with fetched data
          setState(() {
            alertsList = firebaseAlerts;
          });
        }
      });
    } catch (e) {
      print("Error fetching alerts: $e");
      setState(() {
        alertsList = [];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xffD0C3FF),
        title: const Text(
          'Community Alerts',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: alertsList.isEmpty
          ? const Center(
              child: Text(
                'No alerts available',
                style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(10.0),
              itemCount: alertsList.length,
              itemBuilder: (context, index) {
                final alert = alertsList[index];
                final residentName =
                    "${alert['FirstName']} ${alert['LastName']}".toUpperCase();
                final email = alert['Email'] ?? 'Unknown email';
                final addressLocation =
                    "${alert['StreetName']},${alert['Suburb']}, ${alert['City']}, ${alert['Province']}";
                //final address = alert['Alert_Address'] ?? 'No address provided';

                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            residentName,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.teal,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              const Icon(Icons.email, color: Colors.grey),
                              const SizedBox(width: 8),
                              Text(
                                email,
                                style: const TextStyle(
                                  fontSize: 14,
                                  color: Colors.black87,
                                ),
                              ),
                            ],
                          ),
                          const Divider(height: 20, thickness: 1),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Icon(Icons.location_on, color: Colors.grey),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  "Address: $addressLocation",
                                  style: const TextStyle(
                                    fontSize: 14,
                                    color: Colors.black87,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
