import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:khuza_active_realtime/Screen/chatbox.dart';

class StatusReportsPage extends StatefulWidget {
  const StatusReportsPage({super.key});

  @override
  _StatusReportsPageState createState() => _StatusReportsPageState();
}

class _StatusReportsPageState extends State<StatusReportsPage> {
  final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref();
  List<Map<dynamic, dynamic>> post = [];

  @override
  void initState() {
    super.initState();
    fetchCrimeReports();
  }

  Future<void> fetchCrimeReports() async {
    try {
      // Fetch Firebase data
      DatabaseEvent firebaseData =
          await _databaseReference.child('Post').once();
      List<Map<String, dynamic>> firebasePost = [];
      if (firebaseData.snapshot.value != null) {
        final Map<dynamic, dynamic> postsMap =
            firebaseData.snapshot.value as Map<dynamic, dynamic>;

        firebasePost = postsMap.entries.map((entry) {
          final value = entry.value as Map;

          // Extract crime report data and possibly nested Resident data
          final resident =
              value['Resident'] ?? {}; // Fetch nested ResidentModel if exists

          return {
            'Title': value['Title'] ?? 'Unknown Crime Type',
            'Description': value['Description'] ?? 'No details provided',
            'Location': value['Location'] ?? 'Unknown location',
            'Date': value['Date'] ?? 'Unknown date',
            'Time': value['Time'] ?? 'Unknown time',
            'UploadPhoto': value['UploadPhoto'], // Handle photo URL if exists
            'Status': value['Status'] ?? 'Submitted', // Include status
            // Resident details
            'ResidentId': resident['ResidentId'] ?? 'Unknown',
            'FirstName': resident['FirstName'] ?? 'Unknown',
            'LastName': resident['LastName'] ?? 'Unknown',
            'Email': resident['Email'] ?? 'Unknown',
            'StreetName': resident['StreetName'] ?? 'Unknown',
            'Suburb': resident['Suburb'] ?? 'Unknown',
            'City': resident['City'] ?? 'Unknown',
            'Province': resident['Province'] ?? 'Unknown',
          };
        }).toList();
      }

      // Update the state with the fetched data
      setState(() {
        post = firebasePost;
      });
    } catch (e) {
      // Handle any errors
      setState(() {
        post = [];
      });
      print("Error fetching posts: $e");
    }
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'Submitted':
        return Colors.blue;
      case 'Under Investigation':
        return Colors.orange;
      case 'Pending':
        return Colors.yellow;
      case 'Resolved':
        return Colors.green;
      default:
        return Colors.grey; // Unknown status color
    }
  }

  Widget _statusIndicator(String status) {
    return Container(
      width: 12,
      height: 12,
      decoration: BoxDecoration(
        color: _statusColor(status),
        shape: BoxShape.circle,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.teal.shade300,
        title: const Text(
          'Crime Reports',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: post.isEmpty
          ? const Center(
              child: Text(
                'No crime reports available',
                style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(10.0),
              itemCount: post.length,
              itemBuilder: (context, index) {
                final posts = post[index];
                final title = posts['Title'] ?? 'Unknown Crime Type';
                final location = posts['Location'] ?? 'Unknown Location';
                final description =
                    posts['Description'] ?? 'No details provided';
                final date = posts['Date'] ?? 'Unknown date';
                final time = posts['Time'] ?? 'Unknown time';
                final residentName =
                    '${posts['FirstName'] ?? ''} ${posts['LastName'] ?? ''}';
                final uploadPhoto = posts['UploadPhoto'];
                final status = posts['Status'] ?? 'Unknown';

                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title.toUpperCase(),
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            "Location: $location",
                            style: const TextStyle(
                              fontSize: 15,
                              color: Colors.black54,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            "Details: $description",
                            style: const TextStyle(
                              fontSize: 14,
                              color: Colors.black87,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            "Date: $date • Time: $time",
                            style: const TextStyle(
                              fontSize: 14,
                              color: Colors.black54,
                            ),
                          ),
                          const SizedBox(height: 12),
                          uploadPhoto != null
                              ? ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Image.network(
                                    uploadPhoto,
                                    fit: BoxFit.cover,
                                    height: 200,
                                    width: double.infinity,
                                    errorBuilder:
                                        (context, error, stackTrace) =>
                                            const Text('Error loading image'),
                                  ),
                                )
                              : const Text(
                                  'No image available',
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.grey),
                                ),
                          const SizedBox(height: 12),
                          const Divider(),
                          Row(
                            children: [
                              const Text('Reported by: '),
                              Text(
                                residentName,
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              const Text('Status: '),
                              Text(
                                status,
                                style: TextStyle(
                                  color: _statusColor(status),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(width: 8),
                              _statusIndicator(status),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),

      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Navigate to the ChatBotScreen
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ChatBotScreen()),
          );
        },
        backgroundColor: Colors.teal.shade300,
        child: const Icon(Icons.smart_toy),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat, //
    );
  }
}

Color _statusColor(String status) {
  switch (status) {
    case 'Submitted':
      return Colors.blue;
    case 'Under Investigation':
      return Colors.orange;
    case 'Pending':
      return Colors.yellow.shade700;
    case 'Resolved':
      return Colors.green;
    default:
      return Colors.grey;
  }
}

// Helper method for status indicator
Widget _statusIndicator(String status) {
  Color color = _statusColor(status);
  return CircleAvatar(
    radius: 6,
    backgroundColor: color,
  );
}
