import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class AdminAlertsPage extends StatefulWidget {
  const AdminAlertsPage({super.key});

  @override
  _AdminAlertsPageState createState() => _AdminAlertsPageState();
}

class _AdminAlertsPageState extends State<AdminAlertsPage> {
  final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref();
  List<Map<String, dynamic>> alertsList = [];

  @override
  void initState() {
    super.initState();
    fetchFirebaseData();
  }

  Future<void> _deleteAlert(String alertId) async {
    try {
      await _databaseReference.child('Alert').child(alertId).remove();

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Alert deleted successfully')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error deleting alert: $e')),
      );
    }
  }

  Future<void> fetchFirebaseData() async {
    try {
      DatabaseEvent firebaseData =
          await _databaseReference.child('Alert').once();
      List<Map<String, dynamic>> firebaseAlerts = [];

      if (firebaseData.snapshot.value != null) {
        final Map<dynamic, dynamic> alertsMap =
            firebaseData.snapshot.value as Map<dynamic, dynamic>;

        firebaseAlerts = alertsMap.entries.map((entry) {
          final value = entry.value as Map;
          final resident = value['Resident'] ?? {};

          return {
            'id': entry.key, // Add alert key for identification and deletion
            'ResidentId': resident['ResidentId'] ?? 'Unknown',
            'FirstName': resident['FirstName'] ?? 'Unknown',
            'LastName': resident['LastName'] ?? 'Unknown',
            'Email': resident['Email'] ?? 'Unknown',
            'StreetName': resident['StreetName'] ?? 'Unknown',
            'Suburb': resident['Suburb'] ?? 'Unknown',
            'City': resident['City'] ?? 'Unknown',
            'Province': resident['Province'] ?? 'Unknown',
          };
        }).toList();
      }

      setState(() {
        alertsList = firebaseAlerts;
      });
    } catch (e) {
      setState(() {
        alertsList = [];
      });
      print("Error fetching alerts: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xffD0C3FF),
        title: const Text('Community Alerts'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: alertsList.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: alertsList.length,
              itemBuilder: (context, index) {
                final resident = alertsList[index];
                return Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Card(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15)),
                    child: ListTile(
                      title: Text(
                        "${resident['FirstName']} ${resident['LastName']}"
                            .toUpperCase(),
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(resident['Email']),
                          Text(
                              "Address: ${resident['StreetName']} ${resident['Suburb']}"),
                          Text("${resident['City']}, ${resident['Province']}"),
                        ],
                      ),
                      trailing: IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () async {
                            // Confirm deletion with a dialog
                            final confirm = await showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                title: const Text('Delete Alert'),
                                content: const Text(
                                    'Are you sure you want to delete this alert?'),
                                actions: [
                                  TextButton(
                                    onPressed: () =>
                                        Navigator.pop(context, false),
                                    child: const Text('Cancel'),
                                  ),
                                  TextButton(
                                    onPressed: () =>
                                        Navigator.pop(context, true),
                                    child: const Text('Delete',
                                        style: TextStyle(color: Colors.red)),
                                  ),
                                ],
                              ),
                            );
                            if (confirm) {
                              // Call _deleteAlert with the alert ID
                              _deleteAlert(resident['id']);
                            }
                          }),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
